import AVFoundation
import CoreMedia
import Foundation
import ImageIO

enum LivePhotoNativeError: Error, CustomStringConvertible {
    case usage
    case imageReadFailed(URL)
    case imageWriteFailed(URL)
    case videoTrackMissing(URL)
    case metadataFormatFailed
    case writerInputRejected(String)
    case readerFailed(String)
    case writerFailed(String)

    var description: String {
        switch self {
        case .usage:
            return "Usage: LivePhotoNative <input-jpg> <input-mov-or-mp4> <output-dir> [asset-id]"
        case .imageReadFailed(let url):
            return "Unable to read image: \(url.path)"
        case .imageWriteFailed(let url):
            return "Unable to write image: \(url.path)"
        case .videoTrackMissing(let url):
            return "No video track found: \(url.path)"
        case .metadataFormatFailed:
            return "Unable to create still-image-time metadata format"
        case .writerInputRejected(let name):
            return "AVAssetWriter rejected input: \(name)"
        case .readerFailed(let message):
            return "AVAssetReader failed: \(message)"
        case .writerFailed(let message):
            return "AVAssetWriter failed: \(message)"
        }
    }
}

struct LivePhotoNative {
    let imageURL: URL
    let videoURL: URL
    let outputDirectoryURL: URL
    let assetIdentifier: String

    var outputBaseName: String {
        "live-photo-\(assetIdentifier)"
    }

    var outputImageURL: URL {
        outputDirectoryURL.appendingPathComponent("\(outputBaseName).jpg")
    }

    var outputVideoURL: URL {
        outputDirectoryURL.appendingPathComponent("\(outputBaseName).mov")
    }

    func run() throws {
        try FileManager.default.createDirectory(at: outputDirectoryURL, withIntermediateDirectories: true)
        try writeImage()
        try writeVideo()
        print(outputImageURL.path)
        print(outputVideoURL.path)
    }

    private func writeImage() throws {
        guard let source = CGImageSourceCreateWithURL(imageURL as CFURL, nil) else {
            throw LivePhotoNativeError.imageReadFailed(imageURL)
        }
        let jpegType = "public.jpeg" as CFString
        guard let destination = CGImageDestinationCreateWithURL(outputImageURL as CFURL, jpegType, 1, nil) else {
            throw LivePhotoNativeError.imageWriteFailed(outputImageURL)
        }

        var properties = (CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any]) ?? [:]
        var makerApple = (properties[kCGImagePropertyMakerAppleDictionary as String] as? [String: Any]) ?? [:]
        makerApple["17"] = assetIdentifier
        properties[kCGImagePropertyMakerAppleDictionary as String] = makerApple

        CGImageDestinationAddImageFromSource(destination, source, 0, properties as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw LivePhotoNativeError.imageWriteFailed(outputImageURL)
        }
    }

    private func writeVideo() throws {
        if FileManager.default.fileExists(atPath: outputVideoURL.path) {
            try FileManager.default.removeItem(at: outputVideoURL)
        }

        let asset = AVURLAsset(url: videoURL)
        guard let videoTrack = asset.tracks(withMediaType: .video).first else {
            throw LivePhotoNativeError.videoTrackMissing(videoURL)
        }

        let reader = try AVAssetReader(asset: asset)
        let videoOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: nil)
        videoOutput.alwaysCopiesSampleData = false
        if reader.canAdd(videoOutput) {
            reader.add(videoOutput)
        } else {
            throw LivePhotoNativeError.readerFailed("unable to add video output")
        }

        let writer = try AVAssetWriter(outputURL: outputVideoURL, fileType: .mov)
        writer.metadata = [contentIdentifierMetadata()]

        let formatHint = videoTrack.formatDescriptions.first as! CMFormatDescription
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: nil, sourceFormatHint: formatHint)
        videoInput.expectsMediaDataInRealTime = false
        if writer.canAdd(videoInput) {
            writer.add(videoInput)
        } else {
            throw LivePhotoNativeError.writerInputRejected("video")
        }

        guard let metadataDescription = makeStillImageTimeMetadataDescription() else {
            throw LivePhotoNativeError.metadataFormatFailed
        }
        let metadataInput = AVAssetWriterInput(mediaType: .metadata, outputSettings: nil, sourceFormatHint: metadataDescription)
        let metadataAdaptor = AVAssetWriterInputMetadataAdaptor(assetWriterInput: metadataInput)
        if writer.canAdd(metadataInput) {
            writer.add(metadataInput)
        } else {
            throw LivePhotoNativeError.writerInputRejected("metadata")
        }

        guard writer.startWriting() else {
            throw LivePhotoNativeError.writerFailed(writer.error?.localizedDescription ?? "startWriting failed")
        }
        guard reader.startReading() else {
            throw LivePhotoNativeError.readerFailed(reader.error?.localizedDescription ?? "startReading failed")
        }
        writer.startSession(atSourceTime: .zero)

        let queue = DispatchQueue(label: "live-photo-native.writer")
        let group = DispatchGroup()

        group.enter()
        videoInput.requestMediaDataWhenReady(on: queue) {
            while videoInput.isReadyForMoreMediaData {
                if let sample = videoOutput.copyNextSampleBuffer() {
                    if !videoInput.append(sample) {
                        reader.cancelReading()
                        videoInput.markAsFinished()
                        group.leave()
                        return
                    }
                } else {
                    videoInput.markAsFinished()
                    group.leave()
                    return
                }
            }
        }

        group.enter()
        metadataInput.requestMediaDataWhenReady(on: queue) {
            if metadataInput.isReadyForMoreMediaData {
                let groupItem = AVTimedMetadataGroup(
                    items: [stillImageTimeMetadata()],
                    timeRange: CMTimeRange(start: .zero, duration: CMTime(value: 1, timescale: 100))
                )
                _ = metadataAdaptor.append(groupItem)
                metadataInput.markAsFinished()
                group.leave()
            }
        }

        group.wait()

        let finish = DispatchSemaphore(value: 0)
        writer.finishWriting {
            finish.signal()
        }
        finish.wait()

        if reader.status == .failed || reader.status == .cancelled {
            throw LivePhotoNativeError.readerFailed(reader.error?.localizedDescription ?? "\(reader.status.rawValue)")
        }
        if writer.status == .failed || writer.status == .cancelled {
            throw LivePhotoNativeError.writerFailed(writer.error?.localizedDescription ?? "\(writer.status.rawValue)")
        }
    }

    private func contentIdentifierMetadata() -> AVMetadataItem {
        let item = AVMutableMetadataItem()
        item.keySpace = .quickTimeMetadata
        item.key = "com.apple.quicktime.content.identifier" as NSString
        item.identifier = .quickTimeMetadataContentIdentifier
        item.value = assetIdentifier as NSString
        item.dataType = kCMMetadataBaseDataType_UTF8 as String
        return item.copy() as! AVMetadataItem
    }

    private func stillImageTimeMetadata() -> AVMetadataItem {
        let item = AVMutableMetadataItem()
        item.keySpace = .quickTimeMetadata
        item.key = "com.apple.quicktime.still-image-time" as NSString
        item.value = 0 as NSNumber
        item.dataType = kCMMetadataBaseDataType_SInt8 as String
        return item.copy() as! AVMetadataItem
    }

    private func makeStillImageTimeMetadataDescription() -> CMFormatDescription? {
        let specification: [String: Any] = [
            kCMMetadataFormatDescriptionMetadataSpecificationKey_Identifier as String:
                "mdta/com.apple.quicktime.still-image-time",
            kCMMetadataFormatDescriptionMetadataSpecificationKey_DataType as String:
                kCMMetadataBaseDataType_SInt8 as String
        ]
        var description: CMFormatDescription?
        let status = CMMetadataFormatDescriptionCreateWithMetadataSpecifications(
            allocator: kCFAllocatorDefault,
            metadataType: kCMMetadataFormatType_Boxed,
            metadataSpecifications: [specification] as CFArray,
            formatDescriptionOut: &description
        )
        return status == noErr ? description : nil
    }
}

do {
    let args = CommandLine.arguments
    guard args.count == 4 || args.count == 5 else {
        throw LivePhotoNativeError.usage
    }
    let imageURL = URL(fileURLWithPath: args[1])
    let videoURL = URL(fileURLWithPath: args[2])
    let outputDirectoryURL = URL(fileURLWithPath: args[3], isDirectory: true)
    let assetIdentifier = args.count == 5 ? args[4] : UUID().uuidString
    try LivePhotoNative(
        imageURL: imageURL,
        videoURL: videoURL,
        outputDirectoryURL: outputDirectoryURL,
        assetIdentifier: assetIdentifier
    ).run()
} catch let error as LivePhotoNativeError {
    fputs("\(error.description)\n", stderr)
    exit(1)
} catch {
    fputs("\(error.localizedDescription)\n", stderr)
    exit(1)
}
