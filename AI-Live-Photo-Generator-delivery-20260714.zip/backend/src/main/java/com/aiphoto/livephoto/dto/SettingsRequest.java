package com.aiphoto.livephoto.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public record SettingsRequest(
        String apiKey,
        String baseUrl,
        String apiPath,
        String statusPath,
        String model,
        @Min(30) @Max(600) Integer timeoutSeconds,
        @Min(2) @Max(5) Integer videoDuration,
        String resolution,
        @Min(12) @Max(60) Integer fps,
        @Min(0) @Max(5) Integer retryCount
) {
}
