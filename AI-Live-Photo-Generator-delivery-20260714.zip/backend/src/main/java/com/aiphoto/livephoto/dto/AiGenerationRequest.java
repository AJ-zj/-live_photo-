package com.aiphoto.livephoto.dto;

import java.nio.file.Path;

public record AiGenerationRequest(
        Path imagePath,
        String imageUrl,
        String prompt,
        int durationSeconds,
        String resolution,
        int fps
) {
}
