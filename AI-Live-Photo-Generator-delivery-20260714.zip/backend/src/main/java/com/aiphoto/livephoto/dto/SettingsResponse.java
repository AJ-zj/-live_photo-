package com.aiphoto.livephoto.dto;

public record SettingsResponse(
        String provider,
        boolean apiKeyConfigured,
        String baseUrl,
        String apiPath,
        String statusPath,
        String model,
        int timeoutSeconds,
        int videoDuration,
        String resolution,
        int fps,
        int retryCount
) {
}
