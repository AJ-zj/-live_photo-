package com.aiphoto.livephoto.provider;

import com.aiphoto.livephoto.config.AiProperties;
import com.aiphoto.livephoto.dto.AiGenerationRequest;
import com.aiphoto.livephoto.dto.AiGenerationResult;
import com.aiphoto.livephoto.exception.AppException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class SeedanceProvider implements AIProvider {
    private static final Logger log = LoggerFactory.getLogger(SeedanceProvider.class);
    private final AiProperties properties;
    private final WebClient.Builder webClientBuilder;

    public SeedanceProvider(AiProperties properties, WebClient.Builder webClientBuilder) {
        this.properties = properties;
        this.webClientBuilder = webClientBuilder;
    }

    @Override
    public String name() {
        return "seedance";
    }

    @Override
    public AiGenerationResult generateVideo(AiGenerationRequest request) {
        AiProperties.Seedance config = properties.getSeedance();
        validate(config);
        int attempts = Math.max(1, config.getRetryCount() + 1);
        RuntimeException lastError = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                log.info("调用 Seedance Image-to-Video，attempt={}, duration={}, resolution={}, fps={}",
                        attempt, request.durationSeconds(), request.resolution(), request.fps());
                return callSeedance(config, request);
            } catch (RuntimeException exception) {
                lastError = exception;
                log.warn("Seedance 调用失败 attempt={}/{}: {}", attempt, attempts, exception.getMessage());
                if (attempt < attempts) {
                    sleep(1200L * attempt);
                }
            }
        }
        throw new AppException(HttpStatus.BAD_GATEWAY, "Seedance 视频生成失败，请检查 API 配置或稍后重试", lastError);
    }

    private AiGenerationResult callSeedance(AiProperties.Seedance config, AiGenerationRequest request) {
        WebClient client = webClientBuilder
                .baseUrl(config.getBaseUrl())
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + config.getApiKey())
                .build();

        Map<?, ?> submitResponse = submit(client, config, request);
        String videoUrl = firstText(submitResponse, "video_url", "videoUrl", "url", "output_url", "content_url");
        String providerTaskId = firstText(submitResponse, "task_id", "taskId", "id", "taskId", "taskID");

        if (!StringUtils.hasText(videoUrl) && StringUtils.hasText(providerTaskId)) {
            videoUrl = pollVideoUrl(client, config, providerTaskId);
        }
        if (!StringUtils.hasText(videoUrl)) {
            throw new AppException(HttpStatus.BAD_GATEWAY, "Seedance 响应中未找到视频地址");
        }
        Path downloaded = downloadVideo(videoUrl, request.imagePath().getParent().resolve("seedance-output.mp4"));
        return new AiGenerationResult(downloaded, providerTaskId);
    }

    private Map<?, ?> submit(WebClient client, AiProperties.Seedance config, AiGenerationRequest request) {
        String imageUrl = resolveImageUrl(config, request);
        String prompt = request.prompt()
                + " --resolution " + request.resolution()
                + " --duration " + request.durationSeconds()
                + " --camerafixed " + config.isCameraFixed()
                + " --watermark " + config.isWatermark();
        Map<String, Object> body = Map.of(
                "model", config.getModel(),
                "content", List.of(
                        Map.of("type", "text", "text", prompt),
                        Map.of("type", "image_url", "image_url", Map.of("url", imageUrl))
                )
        );
        return client.post()
                .uri(config.getApiPath())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(config.getTimeoutSeconds()))
                .block();
    }

    private String resolveImageUrl(AiProperties.Seedance config, AiGenerationRequest request) {
        if (StringUtils.hasText(config.getImageUrlOverride())) {
            return config.getImageUrlOverride();
        }
        if (StringUtils.hasText(request.imageUrl())) {
            return request.imageUrl();
        }
        throw new AppException("火山方舟图生视频需要公网可访问的图片 URL。请配置 APP_PUBLIC_BASE_URL，或临时配置 SEEDANCE_IMAGE_URL_OVERRIDE。");
    }

    private String pollVideoUrl(WebClient client, AiProperties.Seedance config, String providerTaskId) {
        if (!StringUtils.hasText(config.getStatusPath())) {
            throw new AppException("Seedance 返回异步任务 ID，但未配置 SEEDANCE_STATUS_PATH");
        }
        long deadline = System.currentTimeMillis() + Duration.ofSeconds(config.getTimeoutSeconds()).toMillis();
        while (System.currentTimeMillis() < deadline) {
            sleep(Duration.ofSeconds(config.getPollIntervalSeconds()).toMillis());
            String path = config.getStatusPath().replace("{taskId}", providerTaskId);
            Map<?, ?> response = client.get()
                    .uri(path)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .timeout(Duration.ofSeconds(30))
                    .block();
            String status = firstText(response, "status", "state");
            String videoUrl = firstText(response, "video_url", "videoUrl", "url", "output_url", "content_url");
            if (StringUtils.hasText(videoUrl) && ("success".equalsIgnoreCase(status) || "completed".equalsIgnoreCase(status) || "succeeded".equalsIgnoreCase(status))) {
                return videoUrl;
            }
            if ("failed".equalsIgnoreCase(status) || "error".equalsIgnoreCase(status)) {
                throw new AppException(HttpStatus.BAD_GATEWAY, "Seedance 任务失败");
            }
        }
        throw new AppException(HttpStatus.GATEWAY_TIMEOUT, "Seedance 任务超时");
    }

    private Path downloadVideo(String videoUrl, Path target) {
        try {
            DataBufferUtils.write(
                    WebClient.create()
                    .get()
                    .uri(URI.create(videoUrl))
                    .retrieve()
                            .bodyToFlux(org.springframework.core.io.buffer.DataBuffer.class),
                    target)
                    .timeout(Duration.ofMinutes(5))
                    .block();
            return target;
        } catch (Exception exception) {
            throw new AppException(HttpStatus.BAD_GATEWAY, "下载 Seedance 视频失败", exception);
        }
    }

    private void validate(AiProperties.Seedance config) {
        if (!StringUtils.hasText(config.getApiKey())) {
            throw new AppException("未配置 SEEDANCE_API_KEY");
        }
        if (!StringUtils.hasText(config.getBaseUrl())) {
            throw new AppException("未配置 SEEDANCE_BASE_URL");
        }
        if (!StringUtils.hasText(config.getApiPath())) {
            throw new AppException("未配置 SEEDANCE_API_PATH");
        }
        if (!StringUtils.hasText(config.getModel())) {
            throw new AppException("未配置 SEEDANCE_MODEL");
        }
    }

    private String firstText(Object value, String... keys) {
        if (value == null) {
            return null;
        }
        if (value instanceof List<?> list) {
            for (Object item : list) {
                String found = firstText(item, keys);
                if (StringUtils.hasText(found)) {
                    return found;
                }
            }
            return null;
        }
        if (!(value instanceof Map<?, ?> map)) {
            return null;
        }
        for (String key : keys) {
            Object nestedValue = map.get(key);
            if (nestedValue instanceof String text && StringUtils.hasText(text)) {
                return text;
            }
        }
        for (Object nestedValue : map.values()) {
            String found = firstText(nestedValue, keys);
            if (StringUtils.hasText(found)) {
                return found;
            }
        }
        return null;
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "任务被中断", exception);
        }
    }
}
