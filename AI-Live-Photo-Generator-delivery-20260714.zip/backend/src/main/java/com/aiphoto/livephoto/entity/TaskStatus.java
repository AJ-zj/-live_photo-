package com.aiphoto.livephoto.entity;

public enum TaskStatus {
    WAITING,
    RUNNING,
    SUCCESS,
    FAILED
}
