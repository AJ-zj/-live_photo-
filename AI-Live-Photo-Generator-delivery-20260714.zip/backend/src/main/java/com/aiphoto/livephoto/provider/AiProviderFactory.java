package com.aiphoto.livephoto.provider;

import com.aiphoto.livephoto.config.AiProperties;
import com.aiphoto.livephoto.exception.AppException;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class AiProviderFactory {
    private final AiProperties properties;
    private final List<AIProvider> providers;

    public AiProviderFactory(AiProperties properties, List<AIProvider> providers) {
        this.properties = properties;
        this.providers = providers;
    }

    public AIProvider activeProvider() {
        return providers.stream()
                .filter(provider -> provider.name().equalsIgnoreCase(properties.getActiveProvider()))
                .findFirst()
                .orElseThrow(() -> new AppException("未找到 AI Provider: " + properties.getActiveProvider()));
    }
}
