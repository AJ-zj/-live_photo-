package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AppProperties;
import com.aiphoto.livephoto.exception.AppException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class StorageService {
    private final Path root;
    private final AppProperties properties;

    public StorageService(AppProperties properties) {
        this.properties = properties;
        this.root = Path.of(properties.getStorageRoot()).toAbsolutePath().normalize();
        createDirectory(root);
    }

    public Path taskDirectory(String taskId) {
        Path dir = root.resolve("tasks").resolve(taskId).normalize();
        createDirectory(dir);
        return dir;
    }

    public Path root() {
        return root;
    }

    public Path saveUpload(String taskId, MultipartFile file) {
        validateImage(file);
        String extension = extension(file.getOriginalFilename());
        Path target = taskDirectory(taskId).resolve("original" + extension);
        try {
            file.transferTo(target);
            return target;
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "图片上传保存失败", exception);
        }
    }

    public Path saveUpload(String taskId, byte[] bytes, String filename, String contentType) {
        validateImage(bytes, contentType);
        String extension = extension(filename);
        Path target = taskDirectory(taskId).resolve("original" + extension);
        try {
            Files.write(target, bytes, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            return target;
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "图片上传保存失败", exception);
        }
    }

    public Path resolveTaskFile(String taskId, String filename) {
        Path file = taskDirectory(taskId).resolve(filename).normalize();
        if (!file.startsWith(root) || !Files.exists(file)) {
            throw new AppException(HttpStatus.NOT_FOUND, "文件不存在");
        }
        return file;
    }

    public Path originalFile(String taskId) {
        try {
            Optional<Path> original = Files.list(taskDirectory(taskId))
                    .filter(path -> path.getFileName().toString().startsWith("original."))
                    .findFirst();
            return original.orElseThrow(() -> new AppException(HttpStatus.NOT_FOUND, "原图不存在"));
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "读取原图失败", exception);
        }
    }

    public String publicOriginalUrl(String taskId) {
        if (!StringUtils.hasText(properties.getPublicBaseUrl())) {
            return null;
        }
        String base = properties.getPublicBaseUrl().replaceAll("/+$", "");
        return base + "/public/tasks/" + taskId + "/original";
    }

    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new AppException("请上传图片");
        }
        validateImageContentType(file.getContentType());
    }

    private void validateImage(byte[] bytes, String contentType) {
        if (bytes == null || bytes.length == 0) {
            throw new AppException("请上传图片");
        }
        validateImageContentType(contentType);
        validateImageBytes(bytes, contentType);
    }

    private void validateImageContentType(String contentType) {
        if (contentType == null || !(contentType.equals("image/jpeg") || contentType.equals("image/png") || contentType.equals("image/webp"))) {
            throw new AppException("仅支持 JPG、PNG、WEBP 图片");
        }
    }

    private void validateImageBytes(byte[] bytes, String contentType) {
        boolean valid = switch (contentType) {
            case "image/jpeg" -> bytes.length >= 3
                    && (bytes[0] & 0xff) == 0xff
                    && (bytes[1] & 0xff) == 0xd8
                    && (bytes[2] & 0xff) == 0xff;
            case "image/png" -> bytes.length >= 8
                    && (bytes[0] & 0xff) == 0x89
                    && bytes[1] == 0x50
                    && bytes[2] == 0x4e
                    && bytes[3] == 0x47
                    && bytes[4] == 0x0d
                    && bytes[5] == 0x0a
                    && bytes[6] == 0x1a
                    && bytes[7] == 0x0a;
            case "image/webp" -> bytes.length >= 12
                    && bytes[0] == 0x52
                    && bytes[1] == 0x49
                    && bytes[2] == 0x46
                    && bytes[3] == 0x46
                    && bytes[8] == 0x57
                    && bytes[9] == 0x45
                    && bytes[10] == 0x42
                    && bytes[11] == 0x50;
            default -> false;
        };
        if (!valid) {
            throw new AppException("图片数据与文件类型不匹配");
        }
    }

    private String extension(String name) {
        if (name == null || !name.contains(".")) {
            return ".jpg";
        }
        return name.substring(name.lastIndexOf('.')).toLowerCase();
    }

    private void createDirectory(Path path) {
        try {
            Files.createDirectories(path);
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "创建存储目录失败", exception);
        }
    }
}
