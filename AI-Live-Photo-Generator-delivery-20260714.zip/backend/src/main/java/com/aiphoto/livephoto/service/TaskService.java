package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AiProperties;
import com.aiphoto.livephoto.dto.AiGenerationRequest;
import com.aiphoto.livephoto.dto.AiGenerationResult;
import com.aiphoto.livephoto.dto.TaskResponse;
import com.aiphoto.livephoto.entity.GenerationTask;
import com.aiphoto.livephoto.entity.TaskStatus;
import com.aiphoto.livephoto.entity.TemplateType;
import com.aiphoto.livephoto.exception.AppException;
import com.aiphoto.livephoto.provider.AiProviderFactory;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class TaskService {
    private static final Logger log = LoggerFactory.getLogger(TaskService.class);
    private static final DateTimeFormatter ARCHIVE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC);
    private final Map<String, GenerationTask> tasks = new ConcurrentHashMap<>();
    private final Set<String> reservedTaskIds = ConcurrentHashMap.newKeySet();
    private final AtomicInteger nextTaskSequence = new AtomicInteger(1);
    private final StorageService storageService;
    private final PromptTemplateService promptTemplateService;
    private final AiProviderFactory providerFactory;
    private final LivePhotoService livePhotoService;
    private final TaskMapper taskMapper;
    private final TaskExecutor taskExecutor;
    private final AiProperties aiProperties;

    public TaskService(StorageService storageService,
                       PromptTemplateService promptTemplateService,
                       AiProviderFactory providerFactory,
                       LivePhotoService livePhotoService,
                       TaskMapper taskMapper,
                       TaskExecutor taskExecutor,
                       AiProperties aiProperties) {
        this.storageService = storageService;
        this.promptTemplateService = promptTemplateService;
        this.providerFactory = providerFactory;
        this.livePhotoService = livePhotoService;
        this.taskMapper = taskMapper;
        this.taskExecutor = taskExecutor;
        this.aiProperties = aiProperties;
    }

    @PostConstruct
    public void restoreTasks() {
        Path tasksRoot = storageService.root().resolve("tasks");
        initializeTaskSequence();
        if (!Files.isDirectory(tasksRoot)) {
            return;
        }
        try (var directories = Files.list(tasksRoot)) {
            directories
                    .filter(Files::isDirectory)
                    .map(this::restoreTask)
                    .flatMap(Optional::stream)
                    .forEach(task -> tasks.putIfAbsent(task.getId(), task));
            log.info("已从 storage 恢复任务数量={}", tasks.size());
        } catch (IOException exception) {
            log.warn("从 storage 恢复任务失败", exception);
        }
    }

    public GenerationTask create(MultipartFile image, TemplateType template, int durationSeconds) {
        GenerationTask task = createTask(template, durationSeconds);
        try {
            task.setOriginalFilename(image.getOriginalFilename());
            task.setOriginalPath(storageService.saveUpload(task.getId(), image));
            start(task);
            return task;
        } catch (RuntimeException exception) {
            reservedTaskIds.remove(task.getId());
            throw exception;
        }
    }

    public GenerationTask create(byte[] imageBytes, String filename, String contentType, TemplateType template, int durationSeconds) {
        GenerationTask task = createTask(template, durationSeconds);
        try {
            task.setOriginalFilename(filename);
            task.setOriginalPath(storageService.saveUpload(task.getId(), imageBytes, filename, contentType));
            start(task);
            return task;
        } catch (RuntimeException exception) {
            reservedTaskIds.remove(task.getId());
            throw exception;
        }
    }

    public GenerationTask retry(String taskId) {
        GenerationTask source = getTask(taskId);
        if (source.getStatus() != TaskStatus.FAILED) {
            throw new AppException("只有失败任务可以重试");
        }
        Path original = require(source.getOriginalPath(), "原图不存在，无法重试");
        try {
            String filename = source.getOriginalFilename() == null ? original.getFileName().toString() : source.getOriginalFilename();
            return create(Files.readAllBytes(original), filename, imageContentType(original),
                    source.getTemplateType(), source.getDurationSeconds());
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "读取重试原图失败", exception);
        }
    }

    public List<BatchFile> batchFiles(List<String> taskIds) {
        if (taskIds == null || taskIds.isEmpty()) {
            throw new AppException("请选择要下载的任务");
        }
        return taskIds.stream().distinct().map(this::getTask).map(task -> {
            if (task.getStatus() != TaskStatus.SUCCESS) {
                throw new AppException("任务尚未完成：" + task.getId());
            }
            return new BatchFile(task.getId(), task.getOriginalFilename(),
                    require(task.getJpgPath(), "JPG 文件尚未生成"),
                    require(task.getMovPath(), "MOV 文件尚未生成"));
        }).toList();
    }

    private GenerationTask createTask(TemplateType template, int durationSeconds) {
        if (durationSeconds < 2 || durationSeconds > 5) {
            throw new AppException("视频时长必须在 2 到 5 秒之间");
        }
        GenerationTask task = new GenerationTask(nextTaskId());
        task.setTemplateType(template);
        task.setDurationSeconds(durationSeconds);
        task.setPrompt(promptTemplateService.buildPrompt(template));
        return task;
    }

    private void start(GenerationTask task) {
        tasks.put(task.getId(), task);
        reservedTaskIds.remove(task.getId());
        taskExecutor.execute(() -> runTask(task));
        log.info("创建任务 id={}, template={}, duration={}", task.getId(), task.getTemplateType(), task.getDurationSeconds());
    }

    public TaskResponse get(String taskId) {
        return taskMapper.toResponse(getTask(taskId));
    }

    public List<TaskResponse> list() {
        return tasks.values().stream()
                .sorted(Comparator.comparing(GenerationTask::getCreatedAt).reversed())
                .map(taskMapper::toResponse)
                .toList();
    }

    public Path download(String taskId, String kind) {
        GenerationTask task = getTask(taskId);
        return switch (kind) {
            case "mov" -> require(task.getMovPath(), "MOV 文件尚未生成");
            case "jpg" -> require(task.getJpgPath(), "JPG 文件尚未生成");
            case "live-photo" -> require(task.getLivePhotoZipPath(), "Live Photo 尚未生成");
            default -> throw new AppException(HttpStatus.NOT_FOUND, "下载类型不存在");
        };
    }

    public int archive(List<String> taskIds) {
        if (taskIds == null || taskIds.isEmpty()) {
            throw new AppException("请选择要清理的任务");
        }

        Path archiveRoot = storageService.root()
                .resolve("archived-tasks")
                .resolve(ARCHIVE_FORMATTER.format(Instant.now()))
                .normalize();
        int archived = 0;
        try {
            Files.createDirectories(archiveRoot);
            for (String taskId : taskIds) {
                GenerationTask task = getTask(taskId);
                if (task.getStatus() == TaskStatus.WAITING || task.getStatus() == TaskStatus.RUNNING) {
                    throw new AppException("任务生成中，暂不能清理：" + taskId);
                }
                Path taskDir = storageService.root().resolve("tasks").resolve(taskId).normalize();
                if (!taskDir.startsWith(storageService.root())) {
                    throw new AppException(HttpStatus.BAD_REQUEST, "任务路径非法");
                }
                if (Files.exists(taskDir)) {
                    Files.move(taskDir, archiveRoot.resolve(taskId), StandardCopyOption.REPLACE_EXISTING);
                }
                tasks.remove(taskId);
                archived++;
                log.info("已归档清理任务 id={}", taskId);
            }
            return archived;
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "清理任务失败", exception);
        }
    }

    private void runTask(GenerationTask task) {
        try {
            task.setStatus(TaskStatus.RUNNING);
            task.setProgress(10);
            task.setMessage("正在生成 Seedance 动态视频");
            AiGenerationRequest request = new AiGenerationRequest(
                    task.getOriginalPath(),
                    storageService.publicOriginalUrl(task.getId()),
                    task.getPrompt(),
                    task.getDurationSeconds(),
                    aiProperties.getSeedance().getResolution(),
                    aiProperties.getSeedance().getFps()
            );
            AiGenerationResult result = providerFactory.activeProvider().generateVideo(request);
            task.setMp4Path(result.mp4Path());
            task.setProgress(65);
            task.setMessage("正在生成 Apple Live Photo");
            LivePhotoService.LivePhotoBundle bundle = livePhotoService.create(
                    task.getOriginalPath(),
                    result.mp4Path(),
                    Path.of(task.getOriginalPath().getParent().toString()),
                    task.getDurationSeconds()
            );
            task.setAssetIdentifier(bundle.assetIdentifier());
            task.setJpgPath(bundle.jpg());
            task.setMovPath(bundle.mov());
            task.setLivePhotoZipPath(bundle.zip());
            task.setProgress(100);
            task.setStatus(TaskStatus.SUCCESS);
            task.setMessage("生成完成");
            log.info("任务完成 id={}, assetIdentifier={}", task.getId(), bundle.assetIdentifier());
        } catch (Exception exception) {
            task.setStatus(TaskStatus.FAILED);
            task.setProgress(Math.max(task.getProgress(), 10));
            task.setError(exception.getMessage());
            task.setMessage("生成失败");
            log.error("任务失败 id={}", task.getId(), exception);
        }
    }

    private Optional<GenerationTask> restoreTask(Path taskDir) {
        try {
            String taskId = taskDir.getFileName().toString();
            Optional<Path> jpg = firstMatch(taskDir, "live-photo-", ".jpg");
            Optional<Path> mov = firstMatch(taskDir, "live-photo-", ".mov");
            Optional<Path> zip = firstMatch(taskDir, "live-photo-", ".zip");
            Optional<Path> original = firstMatch(taskDir, "original", null);
            Optional<Path> mp4 = firstMatch(taskDir, "seedance-output", ".mp4");
            if (jpg.isEmpty() && mov.isEmpty() && zip.isEmpty() && original.isEmpty()) {
                return Optional.empty();
            }

            GenerationTask task = new GenerationTask(taskId);
            task.setTemplateType(TemplateType.PORTRAIT);
            task.setDurationSeconds(2);
            task.setPrompt(promptTemplateService.buildPrompt(TemplateType.PORTRAIT));
            task.setOriginalFilename(original.map(path -> path.getFileName().toString()).orElse("已恢复任务"));
            original.ifPresent(task::setOriginalPath);
            jpg.ifPresent(task::setJpgPath);
            mov.ifPresent(task::setMovPath);
            zip.ifPresent(task::setLivePhotoZipPath);
            mp4.ifPresent(task::setMp4Path);
            jpg.map(path -> path.getFileName().toString())
                    .filter(name -> name.startsWith("live-photo-") && name.endsWith(".jpg"))
                    .map(name -> name.substring("live-photo-".length(), name.length() - ".jpg".length()))
                    .ifPresent(task::setAssetIdentifier);
            Instant createdAt = Files.getLastModifiedTime(taskDir).toInstant();
            task.setCreatedAt(createdAt);
            task.setUpdatedAt(createdAt);
            if (jpg.isPresent() && mov.isPresent() && zip.isPresent()) {
                task.setProgress(100);
                task.setStatus(TaskStatus.SUCCESS);
                task.setMessage("已从存储恢复，可下载");
            } else {
                task.setProgress(10);
                task.setStatus(TaskStatus.FAILED);
                task.setMessage("已从存储恢复，文件不完整");
                task.setError("任务文件不完整，请重新生成");
            }
            return Optional.of(task);
        } catch (Exception exception) {
            log.warn("恢复任务目录失败 dir={}", taskDir, exception);
            return Optional.empty();
        }
    }

    private Optional<Path> firstMatch(Path dir, String prefix, String suffix) throws IOException {
        try (var files = Files.list(dir)) {
            return files
                    .filter(Files::isRegularFile)
                    .filter(path -> {
                        String name = path.getFileName().toString();
                        return name.startsWith(prefix) && (suffix == null || name.endsWith(suffix));
                    })
                    .findFirst();
        }
    }

    private GenerationTask getTask(String taskId) {
        GenerationTask task = tasks.get(taskId);
        if (task == null) {
            throw new AppException(HttpStatus.NOT_FOUND, "任务不存在");
        }
        return task;
    }

    private Path require(Path path, String message) {
        if (path == null) {
            throw new AppException(HttpStatus.NOT_FOUND, message);
        }
        return path;
    }

    private String imageContentType(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".webp")) return "image/webp";
        return "image/jpeg";
    }

    private String nextTaskId() {
        Path tasksRoot = storageService.root().resolve("tasks");
        while (true) {
            int sequence = nextTaskSequence.getAndIncrement();
            if (sequence > 999_999) {
                throw new AppException(HttpStatus.SERVICE_UNAVAILABLE, "任务 ID 已达到 999999，请先归档并清理历史数据");
            }
            String candidate = String.valueOf(sequence);
            if (!tasks.containsKey(candidate)
                    && !Files.exists(tasksRoot.resolve(candidate))
                    && reservedTaskIds.add(candidate)) {
                return candidate;
            }
        }
    }

    private void initializeTaskSequence() {
        int maxId = 0;
        try (var paths = Files.walk(storageService.root())) {
            maxId = paths
                    .filter(Files::isDirectory)
                    .map(path -> path.getFileName() == null ? "" : path.getFileName().toString())
                    .filter(name -> name.matches("\\d{1,6}"))
                    .mapToInt(Integer::parseInt)
                    .max()
                    .orElse(0);
        } catch (IOException exception) {
            log.warn("扫描历史任务 ID 失败，将从 1 开始并自动跳过冲突目录", exception);
        }
        nextTaskSequence.set(Math.min(maxId + 1, 1_000_000));
    }

    public record BatchFile(String taskId, String originalFilename, Path jpg, Path mov) {
    }
}
