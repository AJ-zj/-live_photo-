package com.aiphoto.livephoto.controller;

import com.aiphoto.livephoto.service.StorageService;
import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public/tasks")
public class PublicFileController {
    private final StorageService storageService;

    public PublicFileController(StorageService storageService) {
        this.storageService = storageService;
    }

    @GetMapping("/{taskId}/original")
    public ResponseEntity<FileSystemResource> original(@PathVariable String taskId) throws Exception {
        Path file = storageService.originalFile(taskId);
        String contentType = Files.probeContentType(file);
        return ResponseEntity.ok()
                .contentType(contentType == null ? MediaType.IMAGE_JPEG : MediaType.parseMediaType(contentType))
                .contentLength(Files.size(file))
                .body(new FileSystemResource(file));
    }
}
