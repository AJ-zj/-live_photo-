package com.aiphoto.livephoto.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public class AppProperties {
    private String storageRoot = "storage";
    private String ffmpegPath = "ffmpeg";
    private String ffprobePath = "ffprobe";
    private String exiftoolPath = "exiftool";
    private String exiftoolConfigPath = "exiftool-livephoto.config";
    private String livePhotoNativeToolPath = "";
    private String publicBaseUrl;

    public String getStorageRoot() { return storageRoot; }
    public void setStorageRoot(String storageRoot) { this.storageRoot = storageRoot; }
    public String getFfmpegPath() { return ffmpegPath; }
    public void setFfmpegPath(String ffmpegPath) { this.ffmpegPath = ffmpegPath; }
    public String getFfprobePath() { return ffprobePath; }
    public void setFfprobePath(String ffprobePath) { this.ffprobePath = ffprobePath; }
    public String getExiftoolPath() { return exiftoolPath; }
    public void setExiftoolPath(String exiftoolPath) { this.exiftoolPath = exiftoolPath; }
    public String getExiftoolConfigPath() { return exiftoolConfigPath; }
    public void setExiftoolConfigPath(String exiftoolConfigPath) { this.exiftoolConfigPath = exiftoolConfigPath; }
    public String getLivePhotoNativeToolPath() { return livePhotoNativeToolPath; }
    public void setLivePhotoNativeToolPath(String livePhotoNativeToolPath) { this.livePhotoNativeToolPath = livePhotoNativeToolPath; }
    public String getPublicBaseUrl() { return publicBaseUrl; }
    public void setPublicBaseUrl(String publicBaseUrl) { this.publicBaseUrl = publicBaseUrl; }
}
