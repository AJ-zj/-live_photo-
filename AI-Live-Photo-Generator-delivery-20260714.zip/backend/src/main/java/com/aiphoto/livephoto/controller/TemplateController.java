package com.aiphoto.livephoto.controller;

import com.aiphoto.livephoto.dto.ApiResponse;
import com.aiphoto.livephoto.dto.TemplateResponse;
import com.aiphoto.livephoto.service.PromptTemplateService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/templates")
public class TemplateController {
    private final PromptTemplateService promptTemplateService;

    public TemplateController(PromptTemplateService promptTemplateService) {
        this.promptTemplateService = promptTemplateService;
    }

    @GetMapping
    public ApiResponse<List<TemplateResponse>> list() {
        return ApiResponse.ok(promptTemplateService.listTemplates());
    }
}
