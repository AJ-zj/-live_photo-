package com.aiphoto.livephoto.provider;

import com.aiphoto.livephoto.dto.AiGenerationRequest;
import com.aiphoto.livephoto.dto.AiGenerationResult;

public interface AIProvider {
    String name();

    AiGenerationResult generateVideo(AiGenerationRequest request);
}
