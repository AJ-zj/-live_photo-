package com.aiphoto.livephoto.utils;

import com.aiphoto.livephoto.exception.AppException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class ProcessRunner {
    public void run(List<String> command, Duration timeout, String friendlyError) {
        try {
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            boolean finished = process.waitFor(timeout.toSeconds(), TimeUnit.SECONDS);
            String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            if (!finished) {
                process.destroyForcibly();
                throw new AppException(HttpStatus.GATEWAY_TIMEOUT, friendlyError + "：处理超时");
            }
            if (process.exitValue() != 0) {
                throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, friendlyError + "：" + output);
            }
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, friendlyError + "：命令不可用", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, friendlyError + "：任务被中断", exception);
        }
    }
}
