package com.aiphoto.livephoto.dto;

import com.aiphoto.livephoto.entity.TemplateType;
import java.util.List;

public record TemplateResponse(TemplateType type, String label, List<String> motions, String promptRule) {
}
