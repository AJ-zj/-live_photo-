package com.aiphoto.livephoto.controller;

import com.aiphoto.livephoto.dto.ApiResponse;
import com.aiphoto.livephoto.dto.BatchCreateResponse;
import com.aiphoto.livephoto.dto.CreateTaskResponse;
import com.aiphoto.livephoto.dto.DeleteTasksRequest;
import com.aiphoto.livephoto.dto.TaskResponse;
import com.aiphoto.livephoto.entity.GenerationTask;
import com.aiphoto.livephoto.entity.TemplateType;
import com.aiphoto.livephoto.service.TaskService;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<CreateTaskResponse> create(@RequestParam MultipartFile image,
                                                  @RequestParam TemplateType template,
                                                  @RequestParam int durationSeconds) {
        GenerationTask task = taskService.create(image, template, durationSeconds);
        return ApiResponse.ok(new CreateTaskResponse(task.getId()));
    }

    @PostMapping(path = "/batch", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<BatchCreateResponse> createBatch(@RequestParam("images") List<MultipartFile> images,
                                                        @RequestParam TemplateType template,
                                                        @RequestParam int durationSeconds) {
        if (images.isEmpty() || images.size() > 20) {
            throw new com.aiphoto.livephoto.exception.AppException("每批请选择 1 到 20 张图片");
        }
        List<String> taskIds = new ArrayList<>();
        for (MultipartFile image : images) {
            taskIds.add(taskService.create(image, template, durationSeconds).getId());
        }
        return ApiResponse.ok(new BatchCreateResponse(taskIds));
    }

    @PostMapping("/{taskId}/retry")
    public ApiResponse<CreateTaskResponse> retry(@PathVariable String taskId) {
        return ApiResponse.ok(new CreateTaskResponse(taskService.retry(taskId).getId()));
    }

    @GetMapping
    public ApiResponse<List<TaskResponse>> list() {
        return ApiResponse.ok(taskService.list());
    }

    @GetMapping("/{taskId}")
    public ApiResponse<TaskResponse> get(@PathVariable String taskId) {
        return ApiResponse.ok(taskService.get(taskId));
    }

    @DeleteMapping
    public ApiResponse<Integer> delete(@RequestBody DeleteTasksRequest request) {
        return ApiResponse.ok(taskService.archive(request.ids()));
    }

    @GetMapping("/{taskId}/download/{kind}")
    public ResponseEntity<FileSystemResource> download(@PathVariable String taskId, @PathVariable String kind) throws Exception {
        Path file = taskService.download(taskId, kind);
        String filename = file.getFileName().toString();
        MediaType type = switch (kind) {
            case "mov" -> MediaType.valueOf("video/quicktime");
            case "jpg" -> MediaType.IMAGE_JPEG;
            default -> MediaType.APPLICATION_OCTET_STREAM;
        };
        return ResponseEntity.ok()
                .contentType(type)
                .contentLength(Files.size(file))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(filename).build().toString())
                .body(new FileSystemResource(file));
    }

    @PostMapping("/download/batch")
    public ResponseEntity<StreamingResponseBody> downloadBatch(@RequestBody DeleteTasksRequest request) {
        List<TaskService.BatchFile> files = taskService.batchFiles(request.ids());
        StreamingResponseBody body = output -> {
            try (ZipOutputStream zip = new ZipOutputStream(output)) {
                int index = 1;
                for (TaskService.BatchFile file : files) {
                    String folder = String.format("%02d-%s/", index++, safeBaseName(file.originalFilename()));
                    addZipEntry(zip, file.jpg(), folder + file.jpg().getFileName());
                    addZipEntry(zip, file.mov(), folder + file.mov().getFileName());
                }
            }
        };
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=live-photo-batch.zip")
                .body(body);
    }

    private void addZipEntry(ZipOutputStream zip, Path path, String name) throws java.io.IOException {
        zip.putNextEntry(new ZipEntry(name));
        Files.copy(path, zip);
        zip.closeEntry();
    }

    private String safeBaseName(String filename) {
        String value = filename == null ? "live-photo" : filename.replaceFirst("\\.[^.]+$", "");
        value = value.replaceAll("[^a-zA-Z0-9._\\-\\p{L}]", "-");
        return value.isBlank() ? "live-photo" : value;
    }
}
