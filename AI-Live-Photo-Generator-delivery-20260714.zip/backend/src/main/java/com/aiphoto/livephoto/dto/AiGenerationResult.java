package com.aiphoto.livephoto.dto;

import java.nio.file.Path;

public record AiGenerationResult(Path mp4Path, String providerTaskId) {
}
