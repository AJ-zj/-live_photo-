package com.aiphoto.livephoto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication
public class AiLivePhotoGeneratorApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiLivePhotoGeneratorApplication.class, args);
    }
}
