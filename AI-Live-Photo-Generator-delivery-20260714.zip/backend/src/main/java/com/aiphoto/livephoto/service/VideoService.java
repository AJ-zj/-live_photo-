package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AppProperties;
import com.aiphoto.livephoto.utils.ProcessRunner;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class VideoService {
    private final AppProperties properties;
    private final ProcessRunner processRunner;
    private final QuickTimeLivePhotoMetadataWriter livePhotoMetadataWriter;

    public VideoService(AppProperties properties,
                        ProcessRunner processRunner,
                        QuickTimeLivePhotoMetadataWriter livePhotoMetadataWriter) {
        this.properties = properties;
        this.processRunner = processRunner;
        this.livePhotoMetadataWriter = livePhotoMetadataWriter;
    }

    public Path convertToMov(Path inputMp4, Path outputMov, int durationSeconds, String assetIdentifier) {
        processRunner.run(List.of(
                properties.getFfmpegPath(),
                "-y",
                "-i", inputMp4.toString(),
                "-t", String.valueOf(durationSeconds),
                "-vf", "scale='min(1440,iw)':-2",
                "-c:v", "libx264",
                "-profile:v", "high",
                "-pix_fmt", "yuv420p",
                "-movflags", "+faststart",
                "-f", "mov",
                "-brand", "qt  ",
                "-an",
                outputMov.toString()
        ), Duration.ofMinutes(3), "MOV 视频转换失败");
        processRunner.run(List.of(
                properties.getExiftoolPath(),
                "-overwrite_original",
                "-Keys:All=",
                "-Keys:ContentIdentifier=" + assetIdentifier,
                outputMov.toString()
        ), Duration.ofSeconds(30), "MOV Live Photo 元数据写入失败");
        livePhotoMetadataWriter.addStillImageTimeTrack(outputMov);
        return outputMov;
    }
}
