package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AiProperties;
import com.aiphoto.livephoto.dto.SettingsRequest;
import com.aiphoto.livephoto.dto.SettingsResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class SettingsService {
    private final AiProperties properties;

    public SettingsService(AiProperties properties) {
        this.properties = properties;
    }

    public SettingsResponse get() {
        AiProperties.Seedance seedance = properties.getSeedance();
        return new SettingsResponse(
                properties.getActiveProvider(),
                StringUtils.hasText(seedance.getApiKey()),
                seedance.getBaseUrl(),
                seedance.getApiPath(),
                seedance.getStatusPath(),
                seedance.getModel(),
                seedance.getTimeoutSeconds(),
                seedance.getVideoDuration(),
                seedance.getResolution(),
                seedance.getFps(),
                seedance.getRetryCount()
        );
    }

    public SettingsResponse update(SettingsRequest request) {
        AiProperties.Seedance seedance = properties.getSeedance();
        if (StringUtils.hasText(request.apiKey())) seedance.setApiKey(request.apiKey());
        if (request.baseUrl() != null) seedance.setBaseUrl(request.baseUrl());
        if (request.apiPath() != null) seedance.setApiPath(request.apiPath());
        if (request.statusPath() != null) seedance.setStatusPath(request.statusPath());
        if (request.model() != null) seedance.setModel(request.model());
        if (request.timeoutSeconds() != null) seedance.setTimeoutSeconds(request.timeoutSeconds());
        if (request.videoDuration() != null) seedance.setVideoDuration(request.videoDuration());
        if (request.resolution() != null) seedance.setResolution(request.resolution());
        if (request.fps() != null) seedance.setFps(request.fps());
        if (request.retryCount() != null) seedance.setRetryCount(request.retryCount());
        return get();
    }
}
