package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.dto.TaskResponse;
import com.aiphoto.livephoto.dto.WorkflowCreateTaskRequest;
import com.aiphoto.livephoto.dto.WorkflowTaskResponse;
import com.aiphoto.livephoto.entity.GenerationTask;
import com.aiphoto.livephoto.entity.TemplateType;
import com.aiphoto.livephoto.exception.AppException;
import java.util.Base64;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class WorkflowTaskService {
    private final TaskService taskService;
    private final WorkflowLinkBuilder linkBuilder;

    public WorkflowTaskService(TaskService taskService, WorkflowLinkBuilder linkBuilder) {
        this.taskService = taskService;
        this.linkBuilder = linkBuilder;
    }

    public WorkflowTaskResponse create(WorkflowCreateTaskRequest request) {
        if (request == null) {
            throw new AppException("请求体不能为空");
        }
        String base64 = requireText(request.imageBase64(), "imageBase64 不能为空");
        String filename = StringUtils.hasText(request.filename()) ? request.filename() : "workflow-upload.jpg";
        String contentType = contentType(request.contentType(), filename, base64);
        byte[] imageBytes = decodeBase64(base64);
        TemplateType template = request.template() == null ? TemplateType.PORTRAIT : request.template();
        int durationSeconds = request.durationSeconds() == null ? 3 : request.durationSeconds();

        GenerationTask task = taskService.create(imageBytes, filename, contentType, template, durationSeconds);
        return get(task.getId());
    }

    public WorkflowTaskResponse get(String taskId) {
        TaskResponse task = taskService.get(taskId);
        return new WorkflowTaskResponse(taskId, task, linkBuilder.downloads(task));
    }

    private String requireText(String value, String message) {
        if (!StringUtils.hasText(value)) {
            throw new AppException(message);
        }
        return value;
    }

    private byte[] decodeBase64(String value) {
        String payload = value;
        int comma = value.indexOf(',');
        if (value.startsWith("data:") && comma >= 0) {
            payload = value.substring(comma + 1);
        }
        try {
            return Base64.getDecoder().decode(payload);
        } catch (IllegalArgumentException exception) {
            throw new AppException(HttpStatus.BAD_REQUEST, "imageBase64 不是有效的 Base64 图片数据");
        }
    }

    private String contentType(String requested, String filename, String base64) {
        if (StringUtils.hasText(requested)) {
            return requested;
        }
        if (base64.startsWith("data:image/png;")) {
            return "image/png";
        }
        if (base64.startsWith("data:image/webp;")) {
            return "image/webp";
        }
        String lower = filename.toLowerCase();
        if (lower.endsWith(".png")) {
            return "image/png";
        }
        if (lower.endsWith(".webp")) {
            return "image/webp";
        }
        return "image/jpeg";
    }
}
