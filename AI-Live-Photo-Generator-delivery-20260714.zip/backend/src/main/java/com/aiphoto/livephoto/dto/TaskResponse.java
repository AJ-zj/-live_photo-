package com.aiphoto.livephoto.dto;

import com.aiphoto.livephoto.entity.TaskStatus;
import com.aiphoto.livephoto.entity.TemplateType;
import java.time.Instant;

public record TaskResponse(
        String id,
        TaskStatus status,
        TemplateType templateType,
        int durationSeconds,
        int progress,
        String message,
        String error,
        String originalFilename,
        String previewUrl,
        String movUrl,
        String jpgUrl,
        String livePhotoUrl,
        Instant createdAt,
        Instant updatedAt
) {
}
