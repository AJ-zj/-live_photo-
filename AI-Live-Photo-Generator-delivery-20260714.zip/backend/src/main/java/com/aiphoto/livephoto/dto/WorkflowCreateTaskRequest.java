package com.aiphoto.livephoto.dto;

import com.aiphoto.livephoto.entity.TemplateType;

public record WorkflowCreateTaskRequest(
        String imageBase64,
        String filename,
        String contentType,
        TemplateType template,
        Integer durationSeconds
) {
}
