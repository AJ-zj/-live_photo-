package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.dto.TaskResponse;
import com.aiphoto.livephoto.entity.GenerationTask;
import com.aiphoto.livephoto.entity.TaskStatus;
import org.springframework.stereotype.Component;

@Component
public class TaskMapper {
    public TaskResponse toResponse(GenerationTask task) {
        String base = "/api/tasks/" + task.getId() + "/download/";
        return new TaskResponse(
                task.getId(),
                task.getStatus(),
                task.getTemplateType(),
                task.getDurationSeconds(),
                task.getProgress(),
                task.getMessage(),
                task.getError(),
                task.getOriginalFilename(),
                task.getJpgPath() == null ? null : base + "jpg",
                task.getMovPath() == null ? null : base + "mov",
                task.getJpgPath() == null ? null : base + "jpg",
                task.getLivePhotoZipPath() == null ? null : base + "live-photo",
                task.getCreatedAt(),
                task.getUpdatedAt()
        );
    }
}
