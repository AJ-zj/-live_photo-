package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.exception.AppException;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class JpegLivePhotoMetadataWriter {
    private static final byte MARKER = (byte) 0xff;
    private static final byte SOI = (byte) 0xd8;
    private static final byte SOS = (byte) 0xda;
    private static final byte APP0 = (byte) 0xe0;
    private static final byte APP1 = (byte) 0xe1;
    private static final byte[] EXIF_PREFIX = new byte[] {'E', 'x', 'i', 'f', 0, 0};

    public void writeAppleMakerNoteContentIdentifier(Path jpeg, String assetIdentifier) {
        try {
            byte[] input = Files.readAllBytes(jpeg);
            byte[] output = patch(input, assetIdentifier);
            Path temp = jpeg.resolveSibling(jpeg.getFileName() + ".maker.tmp");
            Files.write(temp, output);
            Files.move(temp, jpeg, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException | IllegalArgumentException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "Live Photo JPEG Apple MakerNote 写入失败", exception);
        }
    }

    private byte[] patch(byte[] jpeg, String assetIdentifier) throws IOException {
        if (jpeg.length < 4 || jpeg[0] != MARKER || jpeg[1] != SOI) {
            throw new IllegalArgumentException("not a JPEG file");
        }

        byte[] exifSegment = app1ExifSegment(assetIdentifier);
        ByteArrayOutputStream output = new ByteArrayOutputStream(jpeg.length + exifSegment.length);
        output.write(jpeg, 0, 2);

        int offset = 2;
        boolean inserted = false;
        while (offset + 4 <= jpeg.length && jpeg[offset] == MARKER) {
            byte marker = jpeg[offset + 1];
            if (marker == SOS) {
                if (!inserted) {
                    output.write(exifSegment);
                    inserted = true;
                }
                output.write(jpeg, offset, jpeg.length - offset);
                return output.toByteArray();
            }

            int length = ((jpeg[offset + 2] & 0xff) << 8) | (jpeg[offset + 3] & 0xff);
            if (length < 2 || offset + 2 + length > jpeg.length) {
                throw new IllegalArgumentException("invalid JPEG marker length");
            }

            boolean isExif = marker == APP1 && startsWith(jpeg, offset + 4, EXIF_PREFIX);
            if (!inserted && marker != APP0) {
                output.write(exifSegment);
                inserted = true;
            }
            if (!isExif) {
                output.write(jpeg, offset, 2 + length);
            }
            offset += 2 + length;
        }

        if (!inserted) {
            output.write(exifSegment);
        }
        if (offset < jpeg.length) {
            output.write(jpeg, offset, jpeg.length - offset);
        }
        return output.toByteArray();
    }

    private byte[] app1ExifSegment(String assetIdentifier) throws IOException {
        byte[] tiff = tiff(assetIdentifier);
        int length = 2 + EXIF_PREFIX.length + tiff.length;
        if (length > 0xffff) {
            throw new IllegalArgumentException("EXIF segment too large");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(length + 2);
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeByte(0xff);
        out.writeByte(0xe1);
        out.writeShort(length);
        out.write(EXIF_PREFIX);
        out.write(tiff);
        return bytes.toByteArray();
    }

    private byte[] tiff(String assetIdentifier) throws IOException {
        byte[] makerNote = appleMakerNote(assetIdentifier);
        int ifd0Offset = 8;
        int exifIfdOffset = 26;
        int makerNoteOffset = 44;

        ByteArrayOutputStream bytes = new ByteArrayOutputStream(makerNoteOffset + makerNote.length);
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeShort(0x4d4d);
        out.writeShort(0x002a);
        out.writeInt(ifd0Offset);

        out.writeShort(1);
        out.writeShort(0x8769);
        out.writeShort(4);
        out.writeInt(1);
        out.writeInt(exifIfdOffset);
        out.writeInt(0);

        out.writeShort(1);
        out.writeShort(0x927c);
        out.writeShort(7);
        out.writeInt(makerNote.length);
        out.writeInt(makerNoteOffset);
        out.writeInt(0);

        out.write(makerNote);
        return bytes.toByteArray();
    }

    private byte[] appleMakerNote(String assetIdentifier) throws IOException {
        byte[] value = (assetIdentifier + "\0").getBytes(StandardCharsets.US_ASCII);
        int valueOffset = 32;

        ByteArrayOutputStream bytes = new ByteArrayOutputStream(valueOffset + value.length);
        DataOutputStream out = new DataOutputStream(bytes);
        out.write("Apple iOS".getBytes(StandardCharsets.US_ASCII));
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(1);
        out.writeShort(0x4d4d);
        out.writeShort(1);
        out.writeShort(17);
        out.writeShort(2);
        out.writeInt(value.length);
        out.writeInt(valueOffset);
        out.writeInt(0);
        out.write(value);
        return bytes.toByteArray();
    }

    private boolean startsWith(byte[] source, int offset, byte[] prefix) {
        if (offset + prefix.length > source.length) {
            return false;
        }
        for (int index = 0; index < prefix.length; index += 1) {
            if (source[offset + index] != prefix[index]) {
                return false;
            }
        }
        return true;
    }
}
