package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.dto.TemplateResponse;
import com.aiphoto.livephoto.entity.TemplateType;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PromptTemplateService {
    private final Map<TemplateType, List<String>> motions = new EnumMap<>(TemplateType.class);

    public PromptTemplateService() {
        motions.put(TemplateType.PORTRAIT, List.of("自然眨眼", "轻微微笑", "呼吸起伏", "轻微头部运动", "镜头固定"));
        motions.put(TemplateType.LANDSCAPE, List.of("云层缓慢移动", "水面流动", "树叶轻摇", "自然光影变化"));
        motions.put(TemplateType.PET, List.of("眨眼", "耳朵轻动", "呼吸", "尾巴或身体轻微动作", "镜头固定"));
        motions.put(TemplateType.ANIME, List.of("发丝飘动", "眼神变化", "衣角轻动", "柔和粒子光感", "镜头固定"));
        motions.put(TemplateType.PRODUCT, List.of("轻微转场光影", "产品保持清晰", "背景细微动态", "镜头固定"));
        motions.put(TemplateType.OLD_PHOTO, List.of("轻微景深变化", "自然修复质感", "人物微表情", "保留年代感"));
        motions.put(TemplateType.TRAVEL, List.of("风吹发丝或衣物", "背景人流轻动", "阳光变化", "镜头固定"));
    }

    public List<TemplateResponse> listTemplates() {
        return motions.keySet().stream().map(type ->
                new TemplateResponse(type, type.getLabel(), motions.get(type), buildPrompt(type))
        ).toList();
    }

    public String buildPrompt(TemplateType type) {
        List<String> parts = motions.getOrDefault(type, motions.get(TemplateType.PORTRAIT));
        return "Create a realistic 2-5 second image-to-video live photo animation. "
                + "Keep the original subject identity, composition, and camera framing. "
                + "Use subtle natural motion only: " + String.join(", ", parts) + ". "
                + "No scene change, no extra objects, no text overlays, no camera shake, no distortion.";
    }
}
