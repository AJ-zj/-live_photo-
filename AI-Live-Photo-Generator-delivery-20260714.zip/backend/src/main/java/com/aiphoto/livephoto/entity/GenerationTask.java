package com.aiphoto.livephoto.entity;

import java.nio.file.Path;
import java.time.Instant;

public class GenerationTask {
    private final String id;
    private TaskStatus status = TaskStatus.WAITING;
    private TemplateType templateType;
    private int durationSeconds;
    private String prompt;
    private String originalFilename;
    private Path originalPath;
    private Path jpgPath;
    private Path mp4Path;
    private Path movPath;
    private Path livePhotoZipPath;
    private String assetIdentifier;
    private int progress;
    private String message = "任务已创建";
    private String error;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    public GenerationTask(String id) {
        this.id = id;
    }

    public String getId() { return id; }
    public TaskStatus getStatus() { return status; }
    public void setStatus(TaskStatus status) { this.status = status; touch(); }
    public TemplateType getTemplateType() { return templateType; }
    public void setTemplateType(TemplateType templateType) { this.templateType = templateType; }
    public int getDurationSeconds() { return durationSeconds; }
    public void setDurationSeconds(int durationSeconds) { this.durationSeconds = durationSeconds; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getOriginalFilename() { return originalFilename; }
    public void setOriginalFilename(String originalFilename) { this.originalFilename = originalFilename; }
    public Path getOriginalPath() { return originalPath; }
    public void setOriginalPath(Path originalPath) { this.originalPath = originalPath; }
    public Path getJpgPath() { return jpgPath; }
    public void setJpgPath(Path jpgPath) { this.jpgPath = jpgPath; }
    public Path getMp4Path() { return mp4Path; }
    public void setMp4Path(Path mp4Path) { this.mp4Path = mp4Path; }
    public Path getMovPath() { return movPath; }
    public void setMovPath(Path movPath) { this.movPath = movPath; }
    public Path getLivePhotoZipPath() { return livePhotoZipPath; }
    public void setLivePhotoZipPath(Path livePhotoZipPath) { this.livePhotoZipPath = livePhotoZipPath; }
    public String getAssetIdentifier() { return assetIdentifier; }
    public void setAssetIdentifier(String assetIdentifier) { this.assetIdentifier = assetIdentifier; }
    public int getProgress() { return progress; }
    public void setProgress(int progress) { this.progress = progress; touch(); }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; touch(); }
    public String getError() { return error; }
    public void setError(String error) { this.error = error; touch(); }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }

    private void touch() {
        this.updatedAt = Instant.now();
    }
}
