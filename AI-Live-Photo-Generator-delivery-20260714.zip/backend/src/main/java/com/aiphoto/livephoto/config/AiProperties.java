package com.aiphoto.livephoto.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "ai")
public class AiProperties {
    private String activeProvider = "seedance";
    private Seedance seedance = new Seedance();

    public String getActiveProvider() {
        return activeProvider;
    }

    public void setActiveProvider(String activeProvider) {
        this.activeProvider = activeProvider;
    }

    public Seedance getSeedance() {
        return seedance;
    }

    public void setSeedance(Seedance seedance) {
        this.seedance = seedance;
    }

    public static class Seedance {
        private String apiKey;
        private String baseUrl;
        private String apiPath;
        private String statusPath;
        private String model;
        private int timeoutSeconds = 180;
        private int videoDuration = 3;
        private String resolution = "720p";
        private int fps = 24;
        private int retryCount = 2;
        private String requestMode = "ark-json";
        private int pollIntervalSeconds = 5;
        private boolean cameraFixed = false;
        private boolean watermark = false;
        private String imageUrlOverride;

        public String getApiKey() { return apiKey; }
        public void setApiKey(String apiKey) { this.apiKey = apiKey; }
        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
        public String getApiPath() { return apiPath; }
        public void setApiPath(String apiPath) { this.apiPath = apiPath; }
        public String getStatusPath() { return statusPath; }
        public void setStatusPath(String statusPath) { this.statusPath = statusPath; }
        public String getModel() { return model; }
        public void setModel(String model) { this.model = model; }
        public int getTimeoutSeconds() { return timeoutSeconds; }
        public void setTimeoutSeconds(int timeoutSeconds) { this.timeoutSeconds = timeoutSeconds; }
        public int getVideoDuration() { return videoDuration; }
        public void setVideoDuration(int videoDuration) { this.videoDuration = videoDuration; }
        public String getResolution() { return resolution; }
        public void setResolution(String resolution) { this.resolution = resolution; }
        public int getFps() { return fps; }
        public void setFps(int fps) { this.fps = fps; }
        public int getRetryCount() { return retryCount; }
        public void setRetryCount(int retryCount) { this.retryCount = retryCount; }
        public String getRequestMode() { return requestMode; }
        public void setRequestMode(String requestMode) { this.requestMode = requestMode; }
        public int getPollIntervalSeconds() { return pollIntervalSeconds; }
        public void setPollIntervalSeconds(int pollIntervalSeconds) { this.pollIntervalSeconds = pollIntervalSeconds; }
        public boolean isCameraFixed() { return cameraFixed; }
        public void setCameraFixed(boolean cameraFixed) { this.cameraFixed = cameraFixed; }
        public boolean isWatermark() { return watermark; }
        public void setWatermark(boolean watermark) { this.watermark = watermark; }
        public String getImageUrlOverride() { return imageUrlOverride; }
        public void setImageUrlOverride(String imageUrlOverride) { this.imageUrlOverride = imageUrlOverride; }
    }
}
