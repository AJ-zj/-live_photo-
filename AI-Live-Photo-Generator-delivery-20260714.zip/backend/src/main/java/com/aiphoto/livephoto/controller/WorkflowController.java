package com.aiphoto.livephoto.controller;

import com.aiphoto.livephoto.dto.ApiResponse;
import com.aiphoto.livephoto.dto.WorkflowCreateTaskRequest;
import com.aiphoto.livephoto.dto.WorkflowTaskResponse;
import com.aiphoto.livephoto.service.WorkflowTaskService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/workflow/tasks")
public class WorkflowController {
    private final WorkflowTaskService workflowTaskService;

    public WorkflowController(WorkflowTaskService workflowTaskService) {
        this.workflowTaskService = workflowTaskService;
    }

    @PostMapping
    public ApiResponse<WorkflowTaskResponse> create(@RequestBody WorkflowCreateTaskRequest request) {
        return ApiResponse.ok(workflowTaskService.create(request));
    }

    @GetMapping("/{taskId}")
    public ApiResponse<WorkflowTaskResponse> get(@PathVariable String taskId) {
        return ApiResponse.ok(workflowTaskService.get(taskId));
    }
}
