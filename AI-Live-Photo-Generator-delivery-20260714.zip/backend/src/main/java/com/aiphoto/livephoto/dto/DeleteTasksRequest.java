package com.aiphoto.livephoto.dto;

import java.util.List;

public record DeleteTasksRequest(List<String> ids) {
}
