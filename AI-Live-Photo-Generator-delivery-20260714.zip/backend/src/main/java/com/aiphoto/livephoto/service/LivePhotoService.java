package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AppProperties;
import com.aiphoto.livephoto.exception.AppException;
import com.aiphoto.livephoto.utils.ProcessRunner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class LivePhotoService {
    private final AppProperties properties;
    private final ProcessRunner processRunner;
    private final VideoService videoService;
    private final JpegLivePhotoMetadataWriter jpegLivePhotoMetadataWriter;

    public LivePhotoService(AppProperties properties,
                            ProcessRunner processRunner,
                            VideoService videoService,
                            JpegLivePhotoMetadataWriter jpegLivePhotoMetadataWriter) {
        this.properties = properties;
        this.processRunner = processRunner;
        this.videoService = videoService;
        this.jpegLivePhotoMetadataWriter = jpegLivePhotoMetadataWriter;
    }

    public LivePhotoBundle create(Path sourceImage, Path mp4, Path taskDir, int durationSeconds) {
        String assetId = UUID.randomUUID().toString();
        String baseName = "live-photo-" + assetId;
        Path jpg = taskDir.resolve(baseName + ".jpg");
        Path mov = taskDir.resolve(baseName + ".mov");
        Path zip = taskDir.resolve(baseName + ".zip");

        if (canUseNativeTool()) {
            createWithNativeTool(sourceImage, mp4, taskDir, assetId);
            zip(jpg, mov, zip);
            return new LivePhotoBundle(assetId, jpg, mov, zip);
        }

        normalizeJpeg(sourceImage, jpg);
        writeJpegContentIdentifier(jpg, assetId);
        videoService.convertToMov(mp4, mov, durationSeconds, assetId);
        zip(jpg, mov, zip);
        return new LivePhotoBundle(assetId, jpg, mov, zip);
    }

    private boolean canUseNativeTool() {
        if (!StringUtils.hasText(properties.getLivePhotoNativeToolPath())) {
            return false;
        }
        Path tool = Path.of(properties.getLivePhotoNativeToolPath());
        return Files.isRegularFile(tool) && Files.isExecutable(tool);
    }

    private void createWithNativeTool(Path sourceImage, Path video, Path taskDir, String assetId) {
        processRunner.run(List.of(
                properties.getLivePhotoNativeToolPath(),
                sourceImage.toString(),
                video.toString(),
                taskDir.toString(),
                assetId
        ), Duration.ofMinutes(3), "Apple 原生 Live Photo 生成失败");
    }

    private void normalizeJpeg(Path source, Path target) {
        processRunner.run(List.of(
                properties.getFfmpegPath(),
                "-y",
                "-i", source.toString(),
                "-frames:v", "1",
                "-q:v", "2",
                target.toString()
        ), Duration.ofSeconds(45), "JPEG 生成失败");
    }

    private void writeJpegContentIdentifier(Path jpg, String assetId) {
        processRunner.run(List.of(
                properties.getExiftoolPath(),
                "-config", properties.getExiftoolConfigPath(),
                "-overwrite_original",
                "-XMP-apple-fi:ContentIdentifier=" + assetId,
                jpg.toString()
        ), Duration.ofSeconds(30), "Live Photo JPEG 元数据写入失败，请安装 ExifTool");
        jpegLivePhotoMetadataWriter.writeAppleMakerNoteContentIdentifier(jpg, assetId);
    }

    private void zip(Path jpg, Path mov, Path zip) {
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(zip))) {
            add(output, jpg, jpg.getFileName().toString());
            add(output, mov, mov.getFileName().toString());
        } catch (IOException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "Live Photo 打包失败", exception);
        }
    }

    private void add(ZipOutputStream output, Path file, String name) throws IOException {
        output.putNextEntry(new ZipEntry(name));
        Files.copy(file, output);
        output.closeEntry();
    }

    public record LivePhotoBundle(String assetIdentifier, Path jpg, Path mov, Path zip) {
    }
}
