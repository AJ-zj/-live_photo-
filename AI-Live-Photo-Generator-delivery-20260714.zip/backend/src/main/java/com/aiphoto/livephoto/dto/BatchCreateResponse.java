package com.aiphoto.livephoto.dto;

import java.util.List;

public record BatchCreateResponse(List<String> taskIds) {
}
