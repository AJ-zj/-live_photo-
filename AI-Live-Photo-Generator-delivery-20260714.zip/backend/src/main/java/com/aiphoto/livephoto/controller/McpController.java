package com.aiphoto.livephoto.controller;

import com.aiphoto.livephoto.dto.WorkflowCreateTaskRequest;
import com.aiphoto.livephoto.dto.WorkflowTaskResponse;
import com.aiphoto.livephoto.entity.TemplateType;
import com.aiphoto.livephoto.exception.AppException;
import com.aiphoto.livephoto.service.WorkflowTaskService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mcp")
public class McpController {
    private static final String JSONRPC_VERSION = "2.0";
    private static final String PROTOCOL_VERSION = "2024-11-05";

    private final WorkflowTaskService workflowTaskService;
    private final ObjectMapper objectMapper;

    public McpController(WorkflowTaskService workflowTaskService, ObjectMapper objectMapper) {
        this.workflowTaskService = workflowTaskService;
        this.objectMapper = objectMapper;
    }

    @PostMapping
    public McpResponse handle(@RequestBody McpRequest request) {
        JsonNode id = request == null ? null : request.id();
        try {
            if (request == null || request.method() == null || request.method().isBlank()) {
                throw new McpProtocolException(-32600, "Invalid request: method is required");
            }
            Object result = switch (request.method()) {
                case "initialize" -> initializeResult();
                case "tools/list" -> toolsListResult();
                case "tools/call" -> toolsCallResult(request.params());
                default -> throw new McpProtocolException(-32601, "Method not found: " + request.method());
            };
            return McpResponse.success(id, result);
        } catch (McpProtocolException exception) {
            return McpResponse.error(id, exception.code(), exception.getMessage());
        } catch (AppException exception) {
            return McpResponse.error(id, -32000, exception.getMessage());
        } catch (Exception exception) {
            return McpResponse.error(id, -32603, "Internal error: " + exception.getMessage());
        }
    }

    private Map<String, Object> initializeResult() {
        return linkedMap(
                "protocolVersion", PROTOCOL_VERSION,
                "serverInfo", linkedMap(
                        "name", "ai-live-photo-generator",
                        "version", "0.1.0"
                ),
                "capabilities", linkedMap(
                        "tools", linkedMap()
                )
        );
    }

    private Map<String, Object> toolsListResult() {
        return linkedMap("tools", List.of(
                tool("create_live_photo_task", "上传图片并创建 Seedance Live Photo 生成任务。", linkedMap(
                        "type", "object",
                        "required", List.of("imageBase64"),
                        "properties", linkedMap(
                                "imageBase64", linkedMap("type", "string", "description", "图片 Base64，支持 data:image/...;base64,... 格式。"),
                                "filename", linkedMap("type", "string", "description", "原图文件名，例如 input.jpg。"),
                                "contentType", linkedMap("type", "string", "enum", List.of("image/jpeg", "image/png", "image/webp")),
                                "template", linkedMap("type", "string", "enum", templateNames()),
                                "durationSeconds", linkedMap("type", "integer", "minimum", 2, "maximum", 5)
                        )
                )),
                tool("get_live_photo_task", "查询生成任务状态、进度和下载地址。", linkedMap(
                        "type", "object",
                        "required", List.of("taskId"),
                        "properties", linkedMap("taskId", linkedMap("type", "string"))
                )),
                tool("get_live_photo_downloads", "获取 JPG、MOV、Live Photo ZIP 下载地址。", linkedMap(
                        "type", "object",
                        "required", List.of("taskId"),
                        "properties", linkedMap("taskId", linkedMap("type", "string"))
                ))
        ));
    }

    private Map<String, Object> toolsCallResult(JsonNode params) throws JsonProcessingException {
        String name = requiredText(params, "name");
        JsonNode arguments = params == null ? null : params.path("arguments");
        Object payload = switch (name) {
            case "create_live_photo_task" -> workflowTaskService.create(createTaskRequest(arguments));
            case "get_live_photo_task" -> workflowTaskService.get(requiredText(arguments, "taskId"));
            case "get_live_photo_downloads" -> workflowTaskService.get(requiredText(arguments, "taskId")).downloads();
            default -> throw new McpProtocolException(-32602, "Unknown tool: " + name);
        };
        return linkedMap(
                "content", List.of(linkedMap(
                        "type", "text",
                        "text", objectMapper.writeValueAsString(payload)
                )),
                "isError", false
        );
    }

    private WorkflowCreateTaskRequest createTaskRequest(JsonNode arguments) {
        String template = optionalText(arguments, "template");
        return new WorkflowCreateTaskRequest(
                requiredText(arguments, "imageBase64"),
                optionalText(arguments, "filename"),
                optionalText(arguments, "contentType"),
                template == null ? null : parseTemplate(template),
                optionalInt(arguments, "durationSeconds")
        );
    }

    private TemplateType parseTemplate(String template) {
        try {
            return TemplateType.valueOf(template.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            throw new McpProtocolException(-32602, "Unknown template: " + template);
        }
    }

    private Map<String, Object> tool(String name, String description, Map<String, Object> inputSchema) {
        return linkedMap(
                "name", name,
                "description", description,
                "inputSchema", inputSchema
        );
    }

    private List<String> templateNames() {
        return List.of(TemplateType.PORTRAIT.name(), TemplateType.LANDSCAPE.name(), TemplateType.PET.name(),
                TemplateType.ANIME.name(), TemplateType.PRODUCT.name(), TemplateType.OLD_PHOTO.name(), TemplateType.TRAVEL.name());
    }

    private String requiredText(JsonNode node, String field) {
        String value = optionalText(node, field);
        if (value == null || value.isBlank()) {
            throw new McpProtocolException(-32602, field + " is required");
        }
        return value;
    }

    private String optionalText(JsonNode node, String field) {
        if (node == null || node.isMissingNode() || node.get(field) == null || node.get(field).isNull()) {
            return null;
        }
        return node.get(field).asText();
    }

    private Integer optionalInt(JsonNode node, String field) {
        if (node == null || node.isMissingNode() || node.get(field) == null || node.get(field).isNull()) {
            return null;
        }
        return node.get(field).asInt();
    }

    private Map<String, Object> linkedMap(Object... entries) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 0; i < entries.length; i += 2) {
            map.put((String) entries[i], entries[i + 1]);
        }
        return map;
    }

    public record McpRequest(String jsonrpc, JsonNode id, String method, JsonNode params) {
    }

    public record McpResponse(String jsonrpc, JsonNode id, Object result, McpError error) {
        static McpResponse success(JsonNode id, Object result) {
            return new McpResponse(JSONRPC_VERSION, id, result, null);
        }

        static McpResponse error(JsonNode id, int code, String message) {
            return new McpResponse(JSONRPC_VERSION, id, null, new McpError(code, message));
        }
    }

    public record McpError(int code, String message) {
    }

    private static final class McpProtocolException extends RuntimeException {
        private final int code;

        private McpProtocolException(int code, String message) {
            super(message);
            this.code = code;
        }

        private int code() {
            return code;
        }
    }
}
