package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.config.AppProperties;
import com.aiphoto.livephoto.dto.TaskResponse;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class WorkflowLinkBuilder {
    private final AppProperties appProperties;

    public WorkflowLinkBuilder(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public Map<String, String> downloads(TaskResponse task) {
        Map<String, String> links = new LinkedHashMap<>();
        links.put("jpg", absolute(task.jpgUrl()));
        links.put("mov", absolute(task.movUrl()));
        links.put("livePhotoZip", absolute(task.livePhotoUrl()));
        return links;
    }

    public String statusUrl(String taskId) {
        return apiBase() + "/workflow/tasks/" + taskId;
    }

    private String absolute(String url) {
        if (!StringUtils.hasText(url)) {
            return null;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return url;
        }
        if (url.startsWith("/api/")) {
            return apiBase() + url.substring("/api".length());
        }
        return apiBase() + (url.startsWith("/") ? url : "/" + url);
    }

    private String apiBase() {
        if (StringUtils.hasText(appProperties.getPublicBaseUrl())) {
            return appProperties.getPublicBaseUrl().replaceAll("/+$", "");
        }
        return "/api";
    }
}
