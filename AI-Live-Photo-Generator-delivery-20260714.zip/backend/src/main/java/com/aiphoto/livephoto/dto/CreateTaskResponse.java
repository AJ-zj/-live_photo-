package com.aiphoto.livephoto.dto;

public record CreateTaskResponse(String taskId) {
}
