package com.aiphoto.livephoto.entity;

public enum TemplateType {
    PORTRAIT("人像"),
    LANDSCAPE("风景"),
    PET("宠物"),
    ANIME("动漫"),
    PRODUCT("商品"),
    OLD_PHOTO("老照片"),
    TRAVEL("旅行");

    private final String label;

    TemplateType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
