package com.aiphoto.livephoto.service;

import com.aiphoto.livephoto.exception.AppException;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class QuickTimeLivePhotoMetadataWriter {
    private static final long QUICKTIME_EPOCH_OFFSET_SECONDS = 2_082_844_800L;
    private static final byte[] STILL_IMAGE_TIME_SAMPLE = new byte[] {
            0, 0, 0, 9, 0, 0, 0, 1, 0
    };

    public void addStillImageTimeTrack(Path mov) {
        try {
            byte[] input = Files.readAllBytes(mov);
            byte[] patched = patch(input);
            Path temp = mov.resolveSibling(mov.getFileName() + ".metadata.tmp");
            Files.write(temp, patched);
            Files.move(temp, mov, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException | IllegalArgumentException exception) {
            throw new AppException(HttpStatus.INTERNAL_SERVER_ERROR, "MOV still-image-time timed metadata 写入失败", exception);
        }
    }

    private byte[] patch(byte[] input) throws IOException {
        List<Box> topLevel = readBoxes(input, 0, input.length);
        Box moov = topLevel.stream()
                .filter(box -> "moov".equals(box.type()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("MOV missing moov box"));
        if (hasStillImageTimeTrack(input, moov)) {
            return canonicalizeForLivePhoto(input);
        }

        int oldMoovSize = Math.toIntExact(moov.size());
        int newTrackId = nextTrackId(input, moov);
        byte[] metadataTrak = metadataTrack(newTrackId, 0);
        long metadataSampleOffset = outputLengthWithOldBoxes(topLevel) + metadataTrak.length + 8L;
        metadataTrak = metadataTrack(newTrackId, metadataSampleOffset);
        byte[] oldMoov = slice(input, Math.toIntExact(moov.start()), oldMoovSize);
        int delta = metadataTrak.length;
        byte[] adjustedOldMoov = adjustChunkOffsets(oldMoov, moov.start(), delta);
        byte[] newMoov = appendTrack(adjustedOldMoov, metadataTrak);
        byte[] metadataMdat = box("mdat", STILL_IMAGE_TIME_SAMPLE);

        ByteArrayOutputStream output = new ByteArrayOutputStream(input.length + delta + metadataMdat.length);
        for (Box box : topLevel) {
            if (box == moov) {
                output.write(newMoov);
            } else {
                output.write(input, Math.toIntExact(box.start()), Math.toIntExact(box.size()));
            }
        }
        output.write(metadataMdat);
        return canonicalizeForLivePhoto(output.toByteArray());
    }

    private byte[] canonicalizeForLivePhoto(byte[] input) throws IOException {
        List<Box> topLevel = readBoxes(input, 0, input.length);
        Box moov = topLevel.stream()
                .filter(box -> "moov".equals(box.type()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("MOV missing moov box"));
        List<Box> mdats = topLevel.stream()
                .filter(box -> "mdat".equals(box.type()))
                .toList();
        if (mdats.isEmpty()) {
            return input;
        }

        byte[] oldMoov = slice(input, Math.toIntExact(moov.start()), Math.toIntExact(moov.size()));
        long prefixLength = canonicalPrefixLength(topLevel);
        long mediaDataStart = prefixLength + 8;
        byte[] newMoov = remapChunkOffsets(oldMoov, mdats, mediaDataStart);
        byte[] combinedMdat = combinedMdat(input, mdats);

        ByteArrayOutputStream output = new ByteArrayOutputStream(input.length + 8);
        for (Box box : topLevel) {
            if ("ftyp".equals(box.type())) {
                output.write(input, Math.toIntExact(box.start()), Math.toIntExact(box.size()));
                break;
            }
        }
        output.write(box("wide"));
        for (Box box : topLevel) {
            if (!"ftyp".equals(box.type()) && !"moov".equals(box.type()) && !"mdat".equals(box.type())) {
                output.write(input, Math.toIntExact(box.start()), Math.toIntExact(box.size()));
            }
        }
        output.write(combinedMdat);
        output.write(newMoov);
        return output.toByteArray();
    }

    private long canonicalPrefixLength(List<Box> topLevel) {
        long length = topLevel.stream()
                .filter(box -> "ftyp".equals(box.type()))
                .findFirst()
                .map(Box::size)
                .orElse(0L);
        length += 8;
        length += topLevel.stream()
                .filter(box -> !"ftyp".equals(box.type()) && !"moov".equals(box.type()) && !"mdat".equals(box.type()))
                .mapToLong(Box::size)
                .sum();
        return length;
    }

    private byte[] combinedMdat(byte[] input, List<Box> mdats) throws IOException {
        long payloadSize = mdats.stream()
                .mapToLong(box -> box.size() - box.headerSize())
                .sum();
        if (payloadSize > Integer.MAX_VALUE - 8L) {
            throw new IllegalArgumentException("MOV media data is too large");
        }
        ByteArrayOutputStream payload = new ByteArrayOutputStream(Math.toIntExact(payloadSize));
        for (Box box : mdats) {
            payload.write(
                    input,
                    Math.toIntExact(box.start()) + box.headerSize(),
                    Math.toIntExact(box.size()) - box.headerSize()
            );
        }
        return box("mdat", payload.toByteArray());
    }

    private byte[] remapChunkOffsets(byte[] moov, List<Box> mdats, long newMediaDataStart) {
        List<MediaRange> ranges = mediaRanges(mdats, newMediaDataStart);
        for (Box box : readBoxesRecursive(moov, 8, moov.length)) {
            if ("stco".equals(box.type())) {
                int count = readInt(moov, Math.toIntExact(box.start()) + 12);
                int offset = Math.toIntExact(box.start()) + 16;
                for (int index = 0; index < count; index += 1) {
                    long chunkOffset = Integer.toUnsignedLong(readInt(moov, offset + index * 4));
                    writeUInt32(moov, offset + index * 4, remapChunkOffset(chunkOffset, ranges));
                }
            }
            if ("co64".equals(box.type())) {
                int count = readInt(moov, Math.toIntExact(box.start()) + 12);
                int offset = Math.toIntExact(box.start()) + 16;
                for (int index = 0; index < count; index += 1) {
                    long chunkOffset = readLong(moov, offset + index * 8);
                    writeUInt64(moov, offset + index * 8, remapChunkOffset(chunkOffset, ranges));
                }
            }
        }
        return moov;
    }

    private List<MediaRange> mediaRanges(List<Box> mdats, long newMediaDataStart) {
        List<MediaRange> ranges = new ArrayList<>();
        long cursor = newMediaDataStart;
        for (Box mdat : mdats) {
            long oldStart = mdat.start() + mdat.headerSize();
            long length = mdat.size() - mdat.headerSize();
            ranges.add(new MediaRange(oldStart, oldStart + length, cursor));
            cursor += length;
        }
        return ranges;
    }

    private long remapChunkOffset(long chunkOffset, List<MediaRange> ranges) {
        for (MediaRange range : ranges) {
            if (chunkOffset >= range.oldStart() && chunkOffset < range.oldEnd()) {
                return range.newStart() + chunkOffset - range.oldStart();
            }
        }
        return chunkOffset;
    }

    private long outputLengthWithOldBoxes(List<Box> boxes) {
        return boxes.stream().mapToLong(Box::size).sum();
    }

    private byte[] appendTrack(byte[] moov, byte[] trak) throws IOException {
        List<Box> children = readBoxes(moov, 8, moov.length);
        int insert = children.stream()
                .filter(box -> "trak".equals(box.type()))
                .map(Box::end)
                .max(Comparator.naturalOrder())
                .map(Math::toIntExact)
                .orElse(moov.length);

        ByteArrayOutputStream output = new ByteArrayOutputStream(moov.length + trak.length);
        output.write(moov, 0, insert);
        output.write(trak);
        output.write(moov, insert, moov.length - insert);
        byte[] result = output.toByteArray();
        writeUInt32(result, 0, result.length);
        updateMvhdNextTrackId(result, nextTrackIdInMoov(result));
        return result;
    }

    private int nextTrackIdInMoov(byte[] moov) {
        return readBoxes(moov, 8, moov.length).stream()
                .filter(box -> "trak".equals(box.type()))
                .mapToInt(box -> trackId(moov, box))
                .max()
                .orElse(0) + 1;
    }

    private int nextTrackId(byte[] input, Box moov) {
        return readBoxes(input, Math.toIntExact(moov.start()) + 8, Math.toIntExact(moov.end())).stream()
                .filter(box -> "trak".equals(box.type()))
                .mapToInt(box -> trackId(input, box))
                .max()
                .orElse(0) + 1;
    }

    private boolean hasStillImageTimeTrack(byte[] input, Box moov) {
        byte[] key = "com.apple.quicktime.still-image-time".getBytes(StandardCharsets.US_ASCII);
        return readBoxes(input, Math.toIntExact(moov.start()) + 8, Math.toIntExact(moov.end())).stream()
                .filter(box -> "trak".equals(box.type()))
                .anyMatch(box -> contains(input, box, key) && contains(input, box, fourcc("meta")));
    }

    private int trackId(byte[] data, Box trak) {
        return readBoxes(data, Math.toIntExact(trak.start()) + 8, Math.toIntExact(trak.end())).stream()
                .filter(box -> "tkhd".equals(box.type()))
                .findFirst()
                .map(box -> readInt(data, Math.toIntExact(box.start()) + 20))
                .orElse(0);
    }

    private void updateMvhdNextTrackId(byte[] moov, int nextTrackId) {
        readBoxes(moov, 8, moov.length).stream()
                .filter(box -> "mvhd".equals(box.type()))
                .findFirst()
                .ifPresent(box -> writeUInt32(moov, Math.toIntExact(box.end()) - 4, nextTrackId));
    }

    private byte[] adjustChunkOffsets(byte[] moov, long oldMoovStart, int delta) {
        if (delta == 0) {
            return moov;
        }
        List<Box> boxes = readBoxesRecursive(moov, 8, moov.length);
        for (Box box : boxes) {
            if ("stco".equals(box.type())) {
                int count = readInt(moov, Math.toIntExact(box.start()) + 12);
                int offset = Math.toIntExact(box.start()) + 16;
                for (int index = 0; index < count; index += 1) {
                    long chunkOffset = Integer.toUnsignedLong(readInt(moov, offset + index * 4));
                    if (chunkOffset > oldMoovStart) {
                        writeUInt32(moov, offset + index * 4, chunkOffset + delta);
                    }
                }
            }
            if ("co64".equals(box.type())) {
                int count = readInt(moov, Math.toIntExact(box.start()) + 12);
                int offset = Math.toIntExact(box.start()) + 16;
                for (int index = 0; index < count; index += 1) {
                    long chunkOffset = readLong(moov, offset + index * 8);
                    if (chunkOffset > oldMoovStart) {
                        writeUInt64(moov, offset + index * 8, chunkOffset + delta);
                    }
                }
            }
        }
        return moov;
    }

    private List<Box> readBoxesRecursive(byte[] data, int start, int end) {
        List<Box> result = new ArrayList<>();
        for (Box box : readBoxes(data, start, end)) {
            result.add(box);
            int childStart = Math.toIntExact(box.start()) + box.headerSize();
            if ("meta".equals(box.type())) {
                childStart += 4;
            }
            if (isContainer(box.type()) && childStart < box.end()) {
                result.addAll(readBoxesRecursive(data, childStart, Math.toIntExact(box.end())));
            }
        }
        return result;
    }

    private boolean isContainer(String type) {
        return List.of("moov", "trak", "mdia", "minf", "dinf", "stbl", "edts", "udta", "meta").contains(type);
    }

    private List<Box> readBoxes(byte[] data, int start, int end) {
        List<Box> boxes = new ArrayList<>();
        int offset = start;
        while (offset + 8 <= end) {
            long size = Integer.toUnsignedLong(readInt(data, offset));
            int header = 8;
            if (size == 1) {
                if (offset + 16 > end) {
                    break;
                }
                size = readLong(data, offset + 8);
                header = 16;
            } else if (size == 0) {
                size = end - offset;
            }
            if (size < header || offset + size > end) {
                break;
            }
            boxes.add(new Box(offset, size, ascii(data, offset + 4, 4), header));
            offset += Math.toIntExact(size);
        }
        return boxes;
    }

    private byte[] metadataTrack(int trackId, long sampleOffset) throws IOException {
        long now = Instant.now().getEpochSecond() + QUICKTIME_EPOCH_OFFSET_SECONDS;
        byte[] stbl = box("stbl",
                stsd(),
                stts(),
                stsc(),
                stsz(),
                stco(sampleOffset)
        );
        byte[] minf = box("minf",
                gmhd(),
                handler("dhlr", "alis", "appl", 0, "Core Media Data Handler"),
                dinf(),
                stbl
        );
        byte[] mdia = box("mdia",
                mdhd(now, 600, 6),
                handler("mhlr", "meta", "appl", 1, "Core Media Metadata"),
                minf
        );
        return box("trak",
                tkhd(now, trackId, 6),
                edts(),
                mdia
        );
    }

    private byte[] tkhd(long time, int trackId, int duration) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0x0000000f);
        out.writeInt((int) time);
        out.writeInt((int) time);
        out.writeInt(trackId);
        out.writeInt(0);
        out.writeInt(duration);
        out.writeLong(0);
        out.writeShort(0);
        out.writeShort(0);
        out.writeShort(0);
        out.writeShort(0);
        out.writeInt(0x00010000);
        out.writeInt(0);
        out.writeInt(0);
        out.writeInt(0);
        out.writeInt(0x00010000);
        out.writeInt(0);
        out.writeInt(0);
        out.writeInt(0);
        out.writeInt(0x40000000);
        out.writeInt(0);
        out.writeInt(0);
        return box("tkhd", bytes.toByteArray());
    }

    private byte[] edts() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt(1);
        out.writeInt(6);
        out.writeInt(0);
        out.writeInt(0x00010000);
        return box("edts", box("elst", bytes.toByteArray()));
    }

    private byte[] mdhd(long time, int timescale, int duration) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt((int) time);
        out.writeInt((int) time);
        out.writeInt(timescale);
        out.writeInt(duration);
        out.writeShort(0x55c4);
        out.writeShort(0);
        return box("mdhd", bytes.toByteArray());
    }

    private byte[] handler(String componentType, String handlerType, String manufacturer, int flags, String name) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.write(fourcc(componentType));
        out.write(fourcc(handlerType));
        out.write(fourcc(manufacturer));
        out.writeInt(flags);
        out.writeInt(0);
        byte[] nameBytes = name.getBytes(StandardCharsets.US_ASCII);
        out.writeByte(nameBytes.length);
        out.write(nameBytes);
        return box("hdlr", bytes.toByteArray());
    }

    private byte[] gmhd() throws IOException {
        return box("gmhd", box("gmin", hex("00000000004080008000800000000000")));
    }

    private byte[] dinf() throws IOException {
        ByteArrayOutputStream dref = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(dref);
        out.writeInt(0);
        out.writeInt(1);
        out.write(box("alis", new byte[] {0, 0, 0, 1}));
        return box("dinf", box("dref", dref.toByteArray()));
    }

    private byte[] stsd() throws IOException {
        byte[] key = "com.apple.quicktime.still-image-time".getBytes(StandardCharsets.US_ASCII);
        ByteArrayOutputStream keyd = new ByteArrayOutputStream();
        DataOutputStream keydOut = new DataOutputStream(keyd);
        keydOut.write(fourcc("mdta"));
        keydOut.write(key);

        ByteArrayOutputStream keys = new ByteArrayOutputStream();
        DataOutputStream keysOut = new DataOutputStream(keys);
        keysOut.writeInt(0);
        keysOut.writeInt(1);
        keysOut.write(box("keyd", keyd.toByteArray()));

        ByteArrayOutputStream mebx = new ByteArrayOutputStream();
        DataOutputStream mebxOut = new DataOutputStream(mebx);
        mebxOut.write(new byte[6]);
        mebxOut.writeShort(1);
        mebxOut.write(box("keys", keys.toByteArray()));
        mebxOut.write(box("dtyp", new byte[] {0, 0, 0, 0, 0, 0, 0x00, 0x41}));

        ByteArrayOutputStream stsd = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(stsd);
        out.writeInt(0);
        out.writeInt(1);
        out.write(box("mebx", mebx.toByteArray()));
        return box("stsd", stsd.toByteArray());
    }

    private byte[] stts() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt(1);
        out.writeInt(1);
        out.writeInt(6);
        return box("stts", bytes.toByteArray());
    }

    private byte[] stsc() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt(1);
        out.writeInt(1);
        out.writeInt(1);
        out.writeInt(1);
        return box("stsc", bytes.toByteArray());
    }

    private byte[] stsz() throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt(9);
        out.writeInt(1);
        return box("stsz", bytes.toByteArray());
    }

    private byte[] stco(long sampleOffset) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0);
        out.writeInt(1);
        out.writeInt(Math.toIntExact(sampleOffset));
        return box("stco", bytes.toByteArray());
    }

    private byte[] box(String type, byte[]... payloads) throws IOException {
        int size = 8;
        for (byte[] payload : payloads) {
            size += payload.length;
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(size);
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(size);
        out.write(fourcc(type));
        for (byte[] payload : payloads) {
            out.write(payload);
        }
        return bytes.toByteArray();
    }

    private byte[] fourcc(String value) {
        byte[] bytes = value.getBytes(StandardCharsets.ISO_8859_1);
        if (bytes.length != 4) {
            throw new IllegalArgumentException("invalid fourcc: " + value);
        }
        return bytes;
    }

    private byte[] slice(byte[] data, int start, int size) {
        byte[] result = new byte[size];
        System.arraycopy(data, start, result, 0, size);
        return result;
    }

    private boolean contains(byte[] data, Box box, byte[] needle) {
        int start = Math.toIntExact(box.start());
        int end = Math.toIntExact(box.end()) - needle.length;
        for (int offset = start; offset <= end; offset += 1) {
            boolean matched = true;
            for (int index = 0; index < needle.length; index += 1) {
                if (data[offset + index] != needle[index]) {
                    matched = false;
                    break;
                }
            }
            if (matched) {
                return true;
            }
        }
        return false;
    }

    private int readInt(byte[] data, int offset) {
        return ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).getInt();
    }

    private long readLong(byte[] data, int offset) {
        return ByteBuffer.wrap(data, offset, 8).order(ByteOrder.BIG_ENDIAN).getLong();
    }

    private void writeUInt32(byte[] data, int offset, long value) {
        ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).putInt((int) value);
    }

    private void writeUInt64(byte[] data, int offset, long value) {
        ByteBuffer.wrap(data, offset, 8).order(ByteOrder.BIG_ENDIAN).putLong(value);
    }

    private String ascii(byte[] data, int offset, int length) {
        return new String(data, offset, length, StandardCharsets.ISO_8859_1);
    }

    private byte[] hex(String value) {
        byte[] bytes = new byte[value.length() / 2];
        for (int index = 0; index < bytes.length; index += 1) {
            bytes[index] = (byte) Integer.parseInt(value.substring(index * 2, index * 2 + 2), 16);
        }
        return bytes;
    }

    private record Box(long start, long size, String type, int headerSize) {
        long end() {
            return start + size;
        }
    }

    private record MediaRange(long oldStart, long oldEnd, long newStart) {
    }
}
