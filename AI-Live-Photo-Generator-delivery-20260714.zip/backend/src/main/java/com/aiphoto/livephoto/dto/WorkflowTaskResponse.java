package com.aiphoto.livephoto.dto;

import java.util.Map;

public record WorkflowTaskResponse(
        String taskId,
        TaskResponse task,
        Map<String, String> downloads
) {
}
