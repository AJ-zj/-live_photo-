#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

export LIVE_PHOTO_NATIVE_TOOL_PATH="$ROOT_DIR/tools/livephoto-native/LivePhotoNative"

if [ ! -x "$LIVE_PHOTO_NATIVE_TOOL_PATH" ]; then
  echo "LivePhotoNative is not executable. Build it first:"
  echo "swiftc tools/livephoto-native/LivePhotoNative.swift -o tools/livephoto-native/LivePhotoNative"
  exit 1
fi

if [ ! -f backend/target/app.jar ]; then
  echo "backend/target/app.jar not found."
  echo "Build the backend first, then copy the jar here."
  exit 1
fi

exec java -jar backend/target/app.jar
