@echo off
setlocal

cd /d "%~dp0\..\frontend"

if not exist "node_modules" (
  echo Installing frontend dependencies...
  npm install
  if errorlevel 1 (
    echo npm install failed. Please install Node.js 20+ and try again.
    pause
    exit /b 1
  )
)

echo Starting frontend at http://127.0.0.1:5173
npm run dev

pause
