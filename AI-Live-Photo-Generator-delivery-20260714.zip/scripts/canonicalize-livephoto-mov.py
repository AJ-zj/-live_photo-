#!/usr/bin/env python3
import pathlib
import struct
import sys


CONTAINERS = {b"moov", b"trak", b"mdia", b"minf", b"dinf", b"stbl", b"edts", b"udta", b"meta"}


def u32(data, offset):
    return struct.unpack_from(">I", data, offset)[0]


def u64(data, offset):
    return struct.unpack_from(">Q", data, offset)[0]


def write_u32(data, offset, value):
    struct.pack_into(">I", data, offset, value)


def write_u64(data, offset, value):
    struct.pack_into(">Q", data, offset, value)


def boxes(data, start=0, end=None):
    end = len(data) if end is None else end
    offset = start
    while offset + 8 <= end:
        size = u32(data, offset)
        header = 8
        if size == 1:
            if offset + 16 > end:
                break
            size = u64(data, offset + 8)
            header = 16
        elif size == 0:
            size = end - offset
        if size < header or offset + size > end:
            break
        yield {"start": offset, "end": offset + size, "size": size, "type": bytes(data[offset + 4:offset + 8]), "header": header}
        offset += size


def walk(data, start, end):
    for box in boxes(data, start, end):
        yield box
        child_start = box["start"] + box["header"]
        if box["type"] == b"meta":
            child_start += 4
        if box["type"] in CONTAINERS and child_start < box["end"]:
            yield from walk(data, child_start, box["end"])


def atom(kind, payload=b""):
    return struct.pack(">I4s", len(payload) + 8, kind) + payload


def remap_offset(value, ranges):
    for old_start, old_end, new_start in ranges:
        if old_start <= value < old_end:
            return new_start + value - old_start
    return value


def canonicalize(path):
    data = pathlib.Path(path).read_bytes()
    top = list(boxes(data))
    moov = next((box for box in top if box["type"] == b"moov"), None)
    mdats = [box for box in top if box["type"] == b"mdat"]
    ftyp = next((box for box in top if box["type"] == b"ftyp"), None)
    if not moov or not mdats or not ftyp:
        raise SystemExit("missing ftyp/moov/mdat")

    prefix_len = ftyp["size"] + 8
    prefix_len += sum(box["size"] for box in top if box["type"] not in {b"ftyp", b"moov", b"mdat"})
    new_mdat_payload_start = prefix_len + 8

    ranges = []
    cursor = new_mdat_payload_start
    payloads = []
    for mdat in mdats:
        old_start = mdat["start"] + mdat["header"]
        payload = data[old_start:mdat["end"]]
        ranges.append((old_start, mdat["end"], cursor))
        payloads.append(payload)
        cursor += len(payload)

    new_moov = bytearray(data[moov["start"]:moov["end"]])
    for box in walk(new_moov, 8, len(new_moov)):
        if box["type"] == b"stco":
            count = u32(new_moov, box["start"] + 12)
            offset = box["start"] + 16
            for index in range(count):
                write_u32(new_moov, offset + index * 4, remap_offset(u32(new_moov, offset + index * 4), ranges))
        elif box["type"] == b"co64":
            count = u32(new_moov, box["start"] + 12)
            offset = box["start"] + 16
            for index in range(count):
                write_u64(new_moov, offset + index * 8, remap_offset(u64(new_moov, offset + index * 8), ranges))

    output = bytearray()
    output.extend(data[ftyp["start"]:ftyp["end"]])
    output.extend(atom(b"wide"))
    for box in top:
        if box["type"] not in {b"ftyp", b"moov", b"mdat"}:
            output.extend(data[box["start"]:box["end"]])
    output.extend(atom(b"mdat", b"".join(payloads)))
    output.extend(new_moov)

    target = pathlib.Path(path)
    tmp = target.with_suffix(target.suffix + ".canonical.tmp")
    tmp.write_bytes(output)
    tmp.replace(target)
    print(f"canonicalized {target} ({len(output)} bytes)")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: canonicalize-livephoto-mov.py file.mov")
    canonicalize(sys.argv[1])
