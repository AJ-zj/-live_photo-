@echo off
setlocal

cd /d "%~dp0\.."

if not exist ".env" (
  echo Missing .env. Please copy .env.example to .env and fill SEEDANCE_API_KEY.
  pause
  exit /b 1
)

if not exist "backend\target\app.jar" (
  echo Missing backend\target\app.jar.
  echo Please use the delivered package that includes app.jar, or build the backend first.
  pause
  exit /b 1
)

java -version >nul 2>&1
if errorlevel 1 (
  echo Java 21 is required. Please install Java 21 and try again.
  pause
  exit /b 1
)

echo Starting backend at http://127.0.0.1:8080/api
java -jar backend\target\app.jar

pause
