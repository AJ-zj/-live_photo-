<template>
  <div class="panel">
    <div class="section-header">
      <h2>输出结果</h2>
      <el-button text @click="$router.push('/results')">全部下载</el-button>
    </div>
    <div class="result-grid">
      <div v-for="task in completed" :key="task.id" class="result-card">
        <img :src="task.previewUrl ? absoluteDownload(task.previewUrl) : samplePreview" alt="result" />
        <div class="result-body">
          <strong>{{ task.originalFilename || 'Live Photo' }}</strong>
          <div class="task-meta">{{ task.durationSeconds }}s · {{ templateName(task.templateType) }}</div>
          <div class="result-actions">
            <el-button size="small" :icon="Download" :href="absoluteDownload(task.livePhotoUrl)" tag="a">Live</el-button>
            <el-button size="small" :href="absoluteDownload(task.movUrl)" tag="a">MOV</el-button>
          </div>
        </div>
      </div>
      <div v-if="completed.length === 0" class="task-meta">完成后的 Live Photo、MOV、JPG 会出现在这里。</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { Download } from '@element-plus/icons-vue'
import samplePreview from '../assets/sample-preview.png'
import { absoluteDownload } from '../api/download'
import type { TaskItem, TemplateType } from '../types'

const props = defineProps<{ tasks: TaskItem[] }>()
const completed = computed(() => props.tasks.filter(task => task.status === 'SUCCESS').slice(0, 4))

function templateName(type: TemplateType) {
  return {
    PORTRAIT: '人像',
    LANDSCAPE: '风景',
    PET: '宠物',
    ANIME: '动漫',
    PRODUCT: '商品',
    OLD_PHOTO: '老照片',
    TRAVEL: '旅行'
  }[type]
}
</script>
