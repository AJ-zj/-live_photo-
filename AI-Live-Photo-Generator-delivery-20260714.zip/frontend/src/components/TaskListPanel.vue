<template>
  <div class="panel">
    <div class="section-header">
      <h2>生成任务</h2>
      <el-button text @click="$router.push('/tasks')">查看全部</el-button>
    </div>
    <div class="task-list">
      <div v-if="tasks.length === 0" class="task-meta">暂无任务，上传图片后会显示在这里。</div>
      <div v-for="task in tasks.slice(0, 4)" :key="task.id" class="task-row">
        <img :src="task.previewUrl ? absoluteDownload(task.previewUrl) : samplePreview" alt="task" />
        <div>
          <div class="task-name">{{ task.originalFilename || 'Live Photo 任务' }}</div>
          <div class="task-meta">{{ templateName(task.templateType) }} · {{ task.durationSeconds }}s · {{ task.message }}</div>
        </div>
        <div :class="['status', task.status]">{{ statusText(task.status) }}</div>
        <el-button circle :icon="task.status === 'SUCCESS' ? VideoPlay : Refresh" @click="$router.push(`/tasks/${task.id}`)" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { Refresh, VideoPlay } from '@element-plus/icons-vue'
import samplePreview from '../assets/sample-preview.png'
import { absoluteDownload } from '../api/download'
import type { TaskItem, TaskStatus, TemplateType } from '../types'

defineProps<{ tasks: TaskItem[] }>()

function statusText(status: TaskStatus) {
  return { WAITING: '排队中', RUNNING: '生成中', SUCCESS: '已完成', FAILED: '生成失败' }[status]
}

function templateName(type: TemplateType) {
  return {
    PORTRAIT: '人像',
    LANDSCAPE: '风景',
    PET: '宠物',
    ANIME: '动漫',
    PRODUCT: '商品',
    OLD_PHOTO: '老照片',
    TRAVEL: '旅行'
  }[type]
}
</script>
