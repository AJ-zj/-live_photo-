<template>
  <section class="settings-grid">
    <div class="panel page-panel">
      <div class="section-header">
        <h2>API 配置</h2>
        <span class="status-pill"><span class="dot"></span>{{ form.provider || 'seedance' }}</span>
      </div>
      <el-alert
        title="Apple 实况照片导出需要使用 Mac 本机后端启动；Docker 后端只能作为通用回退。"
        type="warning"
        :closable="false"
        show-icon
        style="margin-bottom: 18px"
      />
      <el-form label-width="120px">
        <el-form-item label="API Key">
          <el-input v-model="apiKey" show-password placeholder="留空则不覆盖当前 Key" />
        </el-form-item>
        <el-form-item label="Base URL">
          <el-input v-model="form.baseUrl" placeholder="从 .env 或配置文件读取" />
        </el-form-item>
        <el-form-item label="API Path">
          <el-input v-model="form.apiPath" />
        </el-form-item>
        <el-form-item label="Status Path">
          <el-input v-model="form.statusPath" placeholder="/tasks/{taskId}" />
        </el-form-item>
        <el-form-item label="Model">
          <el-input v-model="form.model" />
        </el-form-item>
        <el-button type="primary" :loading="saving" @click="save">保存配置</el-button>
      </el-form>
    </div>

    <div class="panel page-panel">
      <div class="section-header">
        <h2>视频参数</h2>
      </div>
      <el-form label-width="120px">
        <el-form-item label="默认时长">
          <el-input-number v-model="form.videoDuration" :min="2" :max="5" />
        </el-form-item>
        <el-form-item label="分辨率">
          <el-select v-model="form.resolution">
            <el-option label="720p" value="720p" />
            <el-option label="1080p" value="1080p" />
          </el-select>
        </el-form-item>
        <el-form-item label="FPS">
          <el-input-number v-model="form.fps" :min="12" :max="60" />
        </el-form-item>
        <el-form-item label="超时秒数">
          <el-input-number v-model="form.timeoutSeconds" :min="30" :max="600" />
        </el-form-item>
        <el-form-item label="重试次数">
          <el-input-number v-model="form.retryCount" :min="0" :max="5" />
        </el-form-item>
      </el-form>
    </div>
  </section>

  <section class="panel page-panel" style="margin-top: 18px">
    <div class="section-header">
      <h2>模板管理</h2>
    </div>
    <el-table :data="templates">
      <el-table-column prop="label" label="模板" width="120" />
      <el-table-column label="动作规则">
        <template #default="{ row }">
          <el-tag v-for="motion in row.motions" :key="motion" style="margin: 3px">{{ motion }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="promptRule" label="自动 Prompt" min-width="320" />
    </el-table>
  </section>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getSettings, getTemplates, updateSettings } from '../api/client'
import type { Settings, TemplateItem } from '../types'

const form = reactive<Settings>({
  provider: 'seedance',
  apiKeyConfigured: false,
  baseUrl: '',
  apiPath: '',
  statusPath: '',
  model: '',
  timeoutSeconds: 180,
  videoDuration: 3,
  resolution: '720p',
  fps: 24,
  retryCount: 2
})
const apiKey = ref('')
const saving = ref(false)
const templates = ref<TemplateItem[]>([])

async function save() {
  saving.value = true
  try {
    Object.assign(form, await updateSettings({ ...form, apiKey: apiKey.value || undefined }))
    apiKey.value = ''
    ElMessage.success('配置已保存到运行时')
  } catch (error) {
    ElMessage.error((error as Error).message)
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  Object.assign(form, await getSettings())
  templates.value = await getTemplates()
})
</script>
