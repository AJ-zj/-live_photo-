<template>
  <section class="workspace-grid">
    <div class="panel hero-preview">
      <video v-if="active?.movUrl" class="result-video" controls autoplay loop muted :src="absoluteDownload(active.movUrl)" />
      <img v-else :src="active?.previewUrl ? absoluteDownload(active.previewUrl) : samplePreview" alt="preview" />
      <div class="live-badge">
        <span class="live-ring"></span>
        LIVE
      </div>
    </div>

    <div class="panel control-panel">
      <div class="step-title"><span class="step-index">✓</span>输出下载</div>
      <p class="task-meta">Live Photo ZIP 内含文件名一致、共享 Asset Identifier 的 JPEG + MOV。</p>
      <el-alert
        v-if="!active"
        title="暂无完成任务"
        type="info"
        show-icon
        :closable="false"
      />
      <template v-else>
        <el-descriptions :column="1" border>
          <el-descriptions-item label="任务 ID">{{ active.id }}</el-descriptions-item>
          <el-descriptions-item label="状态">{{ active.status }}</el-descriptions-item>
          <el-descriptions-item label="时长">{{ active.durationSeconds }} 秒</el-descriptions-item>
          <el-descriptions-item label="文件">{{ active.originalFilename }}</el-descriptions-item>
        </el-descriptions>
        <div class="result-actions" style="margin-top: 18px">
          <el-button type="primary" :icon="Download" tag="a" :href="absoluteDownload(active.livePhotoUrl)">下载 Live Photo</el-button>
          <el-button tag="a" :href="absoluteDownload(active.movUrl)">下载 MOV</el-button>
          <el-button tag="a" :href="absoluteDownload(active.jpgUrl)">下载 JPG</el-button>
        </div>
      </template>
    </div>
  </section>

  <section style="margin-top: 18px">
    <ResultStrip :tasks="tasks" />
  </section>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { Download } from '@element-plus/icons-vue'
import ResultStrip from '../components/ResultStrip.vue'
import samplePreview from '../assets/sample-preview.png'
import { absoluteDownload } from '../api/download'
import { getTask, listTasks } from '../api/client'
import type { TaskItem } from '../types'

const route = useRoute()
const tasks = ref<TaskItem[]>([])
const selected = ref<TaskItem>()
const active = computed(() => selected.value || tasks.value.find(task => task.status === 'SUCCESS'))

onMounted(async () => {
  const id = route.params.id as string | undefined
  tasks.value = await listTasks()
  if (id) selected.value = await getTask(id)
})
</script>
