<template>
  <section class="workspace-grid batch-workspace">
    <div class="panel batch-selection-panel">
      <div class="section-header batch-heading">
        <div>
          <span class="eyebrow">BATCH STUDIO</span>
          <h2>批量图片</h2>
          <p class="task-meta">一次最多 20 张，每张都会生成独立的 Live Photo。</p>
        </div>
        <el-tag v-if="selectedFiles.length" type="primary" effect="dark" round>{{ selectedFiles.length }} 张</el-tag>
      </div>

      <el-upload
        class="upload-zone batch-upload"
        drag
        multiple
        :limit="20"
        :auto-upload="false"
        :show-file-list="false"
        accept="image/jpeg,image/png,image/webp"
        :on-change="handleFile"
        :on-exceed="handleExceed"
      >
        <div class="upload-inner">
          <el-icon class="upload-icon"><UploadFilled /></el-icon>
          <div>点击选择或拖入多张图片</div>
          <small>JPG / PNG / WEBP · 单张不超过 50MB</small>
        </div>
      </el-upload>

      <div v-if="selectedFiles.length" class="batch-thumb-grid">
        <div
          v-for="item in selectedFiles"
          :key="item.uid"
          class="batch-thumb"
          :class="{ active: item.uid === activePreviewUid }"
          role="button"
          tabindex="0"
          @click="activePreviewUid = item.uid"
        >
          <img :src="item.preview" :alt="item.file.name" />
          <span class="batch-thumb-name">{{ item.file.name }}</span>
          <el-button class="batch-remove" circle size="small" :icon="Close" @click.stop="removeFile(item.uid)" />
        </div>
      </div>
      <div v-else class="batch-empty-preview">
        <img :src="samplePreview" alt="Live Photo preview" />
        <div>选中的图片会在这里排队</div>
      </div>
    </div>

    <div class="panel control-panel batch-control-panel">
      <div class="step">
        <div class="step-title"><span class="step-index">1</span>统一模板</div>
        <div class="template-grid">
          <button
            v-for="item in templates"
            :key="item.type"
            class="template-button"
            :class="{ active: item.type === template }"
            @click="template = item.type"
          >
            {{ item.label }}
          </button>
        </div>
      </div>

      <div class="step">
        <div class="step-title"><span class="step-index">2</span>统一动作时长</div>
        <div class="duration-row">
          <el-button
            v-for="value in [2, 3, 4, 5]"
            :key="value"
            :type="durationSeconds === value ? 'primary' : 'default'"
            @click="durationSeconds = value"
          >
            {{ value }}s
          </el-button>
        </div>
      </div>

      <div class="batch-summary">
        <div><span>待生成</span><strong>{{ selectedFiles.length }}</strong></div>
        <div><span>预计输出</span><strong>{{ selectedFiles.length * 2 }} 个文件</strong></div>
        <div><span>并发策略</span><strong>3 个任务</strong></div>
      </div>

      <el-progress v-if="creating || batchTasks.length" :percentage="batchProgress" :stroke-width="9" />
      <el-button class="primary-action" type="primary" :loading="creating" :disabled="!selectedFiles.length" @click="submitBatch">
        {{ creating ? '正在创建任务' : selectedFiles.length ? `开始生成 ${selectedFiles.length} 张` : '请先选择图片' }}
      </el-button>
    </div>
  </section>

  <section v-if="batchTasks.length" class="panel batch-progress-panel">
    <div class="section-header">
      <div>
        <h2>本批进度</h2>
        <p class="task-meta">{{ successCount }} 个完成 · {{ runningCount }} 个处理中 · {{ failedCount }} 个失败</p>
      </div>
      <el-button type="primary" :icon="Download" :disabled="successCount === 0" @click="downloadCompleted">
        下载已完成（{{ successCount }}）
      </el-button>
    </div>
    <div class="batch-task-list">
      <div v-for="task in batchTasks" :key="task.id" class="batch-task-row">
        <img :src="task.previewUrl ? absoluteDownload(task.previewUrl) : samplePreview" alt="task" />
        <div class="batch-task-info">
          <strong>{{ task.originalFilename || task.id }}</strong>
          <span>{{ task.error || task.message }}</span>
        </div>
        <el-progress :percentage="task.progress" :status="task.status === 'FAILED' ? 'exception' : task.status === 'SUCCESS' ? 'success' : undefined" />
        <span :class="['status', task.status]">{{ statusText(task.status) }}</span>
        <el-button v-if="task.status === 'FAILED'" size="small" :loading="retryingIds.has(task.id)" @click="retry(task)">重试</el-button>
        <el-button v-else-if="task.status === 'SUCCESS'" size="small" tag="a" :href="absoluteDownload(task.livePhotoUrl)">下载</el-button>
      </div>
    </div>
  </section>

  <section class="lower-grid">
    <TaskListPanel :tasks="tasks" />
    <ResultStrip :tasks="tasks" />
  </section>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { ElMessage, type UploadFile } from 'element-plus'
import { Close, Download, UploadFilled } from '@element-plus/icons-vue'
import samplePreview from '../assets/sample-preview.png'
import TaskListPanel from '../components/TaskListPanel.vue'
import ResultStrip from '../components/ResultStrip.vue'
import { createBatchTasks, downloadBatch, getTemplates, listTasks, retryTask } from '../api/client'
import { absoluteDownload } from '../api/download'
import type { TaskItem, TaskStatus, TemplateItem, TemplateType } from '../types'

interface SelectedFile {
  uid: number
  file: File
  preview: string
}

const templates = ref<TemplateItem[]>([])
const tasks = ref<TaskItem[]>([])
const selectedFiles = ref<SelectedFile[]>([])
const activePreviewUid = ref<number>()
const batchTaskIds = ref<string[]>(JSON.parse(localStorage.getItem('activeBatchTaskIds') || '[]'))
const template = ref<TemplateType>('PORTRAIT')
const durationSeconds = ref(2)
const creating = ref(false)
const retryingIds = ref(new Set<string>())
let timer: number | undefined

const batchTasks = computed(() => batchTaskIds.value.map(id => tasks.value.find(task => task.id === id)).filter(Boolean) as TaskItem[])
const successCount = computed(() => batchTasks.value.filter(task => task.status === 'SUCCESS').length)
const failedCount = computed(() => batchTasks.value.filter(task => task.status === 'FAILED').length)
const runningCount = computed(() => batchTasks.value.filter(task => task.status === 'RUNNING' || task.status === 'WAITING').length)
const batchProgress = computed(() => batchTasks.value.length
  ? Math.round(batchTasks.value.reduce((sum, task) => sum + task.progress, 0) / batchTasks.value.length)
  : 0)

function handleFile(file: UploadFile) {
  if (!file.raw || selectedFiles.value.some(item => item.uid === file.uid)) return
  if (file.raw.size > 50 * 1024 * 1024) {
    ElMessage.warning(`${file.name} 超过 50MB，已忽略`)
    return
  }
  selectedFiles.value.push({ uid: file.uid, file: file.raw, preview: URL.createObjectURL(file.raw) })
  activePreviewUid.value ||= file.uid
}

function handleExceed() {
  ElMessage.warning('每批最多选择 20 张图片')
}

function removeFile(uid: number) {
  const item = selectedFiles.value.find(file => file.uid === uid)
  if (item) URL.revokeObjectURL(item.preview)
  selectedFiles.value = selectedFiles.value.filter(file => file.uid !== uid)
  if (activePreviewUid.value === uid) activePreviewUid.value = selectedFiles.value[0]?.uid
}

async function submitBatch() {
  if (!selectedFiles.value.length) return
  creating.value = true
  try {
    const result = await createBatchTasks(selectedFiles.value.map(item => item.file), template.value, durationSeconds.value)
    batchTaskIds.value = result.taskIds
    localStorage.setItem('activeBatchTaskIds', JSON.stringify(result.taskIds))
    selectedFiles.value.forEach(item => URL.revokeObjectURL(item.preview))
    selectedFiles.value = []
    await refresh()
    ElMessage.success(`已创建 ${result.taskIds.length} 个生成任务`)
  } catch (error) {
    ElMessage.error((error as Error).message)
  } finally {
    creating.value = false
  }
}

async function retry(task: TaskItem) {
  retryingIds.value = new Set(retryingIds.value).add(task.id)
  try {
    const { taskId } = await retryTask(task.id)
    batchTaskIds.value = batchTaskIds.value.map(id => id === task.id ? taskId : id)
    localStorage.setItem('activeBatchTaskIds', JSON.stringify(batchTaskIds.value))
    await refresh()
  } catch (error) {
    ElMessage.error((error as Error).message)
  } finally {
    const next = new Set(retryingIds.value)
    next.delete(task.id)
    retryingIds.value = next
  }
}

async function downloadCompleted() {
  await downloadBatch(batchTasks.value.filter(task => task.status === 'SUCCESS').map(task => task.id))
}

function statusText(status: TaskStatus) {
  return { WAITING: '排队中', RUNNING: '生成中', SUCCESS: '已完成', FAILED: '失败' }[status]
}

async function refresh() {
  tasks.value = await listTasks()
}

onMounted(async () => {
  templates.value = await getTemplates()
  await refresh()
  timer = window.setInterval(refresh, 3000)
})

onUnmounted(() => {
  if (timer) window.clearInterval(timer)
  selectedFiles.value.forEach(item => URL.revokeObjectURL(item.preview))
})
</script>
