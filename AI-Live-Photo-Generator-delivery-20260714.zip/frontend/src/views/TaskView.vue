<template>
  <section class="panel page-panel">
    <div class="section-header">
      <h2>任务状态</h2>
      <div class="header-actions">
        <el-button @click="selectFailed" :disabled="failedTasks.length === 0">选择失败</el-button>
        <el-button type="danger" plain @click="clearSelected" :disabled="selectedTasks.length === 0">清理选中</el-button>
        <el-button :icon="Refresh" @click="refresh">刷新</el-button>
      </div>
    </div>
    <el-table
      ref="tableRef"
      :data="displayTasks"
      row-key="id"
      style="width: 100%"
      @selection-change="onSelectionChange"
    >
      <el-table-column type="selection" width="52" :selectable="canClean" />
      <el-table-column label="任务" min-width="260">
        <template #default="{ row }">
          <div class="task-name">{{ row.originalFilename || row.id }}</div>
          <div class="task-meta">{{ row.id }}</div>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="120">
        <template #default="{ row }">
          <span :class="['status', row.status]">{{ statusText(row.status) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="进度" min-width="180">
        <template #default="{ row }">
          <el-progress :percentage="row.progress" />
        </template>
      </el-table-column>
      <el-table-column label="模板" width="110">
        <template #default="{ row }">{{ row.templateType }}</template>
      </el-table-column>
      <el-table-column label="消息" min-width="220">
        <template #default="{ row }">{{ row.error || row.message }}</template>
      </el-table-column>
      <el-table-column label="操作" width="180">
        <template #default="{ row }">
          <el-button size="small" @click="$router.push(`/results/${row.id}`)" :disabled="row.status !== 'SUCCESS'">结果</el-button>
          <el-button size="small" @click="$router.push('/')">新建</el-button>
        </template>
      </el-table-column>
    </el-table>
  </section>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { Refresh } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox, type TableInstance } from 'element-plus'
import { deleteTasks, getTask, listTasks } from '../api/client'
import type { TaskItem, TaskStatus } from '../types'

const route = useRoute()
const tasks = ref<TaskItem[]>([])
const selectedTasks = ref<TaskItem[]>([])
const tableRef = ref<TableInstance>()
let timer: number | undefined

const displayTasks = computed(() => tasks.value)
const failedTasks = computed(() => tasks.value.filter(task => task.status === 'FAILED'))

function statusText(status: TaskStatus) {
  return { WAITING: '排队中', RUNNING: '生成中', SUCCESS: '完成', FAILED: '失败' }[status]
}

function canClean(row: TaskItem) {
  return row.status === 'SUCCESS' || row.status === 'FAILED'
}

function onSelectionChange(selection: TaskItem[]) {
  selectedTasks.value = selection
}

function selectFailed() {
  tableRef.value?.clearSelection()
  failedTasks.value.forEach(task => tableRef.value?.toggleRowSelection(task, true))
}

async function clearSelected() {
  const ids = selectedTasks.value.map(task => task.id)
  await ElMessageBox.confirm(`确定清理选中的 ${ids.length} 条任务记录吗？文件会被移动到服务器归档目录。`, '清理记录', {
    confirmButtonText: '清理',
    cancelButtonText: '取消',
    type: 'warning'
  })
  const count = await deleteTasks(ids)
  ElMessage.success(`已清理 ${count} 条记录`)
  selectedTasks.value = []
  tableRef.value?.clearSelection()
  await refresh()
}

async function refresh() {
  const id = route.params.id as string | undefined
  tasks.value = id ? [await getTask(id)] : await listTasks()
}

onMounted(async () => {
  await refresh()
  timer = window.setInterval(refresh, 3000)
})

onUnmounted(() => {
  if (timer) window.clearInterval(timer)
})
</script>
