export type TemplateType = 'PORTRAIT' | 'LANDSCAPE' | 'PET' | 'ANIME' | 'PRODUCT' | 'OLD_PHOTO' | 'TRAVEL'
export type TaskStatus = 'WAITING' | 'RUNNING' | 'SUCCESS' | 'FAILED'

export interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
}

export interface TemplateItem {
  type: TemplateType
  label: string
  motions: string[]
  promptRule: string
}

export interface TaskItem {
  id: string
  status: TaskStatus
  templateType: TemplateType
  durationSeconds: number
  progress: number
  message: string
  error?: string
  originalFilename?: string
  previewUrl?: string
  movUrl?: string
  jpgUrl?: string
  livePhotoUrl?: string
  createdAt: string
  updatedAt: string
}

export interface Settings {
  provider: string
  apiKeyConfigured: boolean
  baseUrl: string
  apiPath: string
  statusPath: string
  model: string
  timeoutSeconds: number
  videoDuration: number
  resolution: string
  fps: number
  retryCount: number
}
