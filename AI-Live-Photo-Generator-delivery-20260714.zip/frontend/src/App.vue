<template>
  <div class="app-shell">
    <header class="topbar">
      <router-link class="brand" to="/">
        <span class="brand-mark">LP</span>
        <span>
          <strong>AI Live Photo 生成器</strong>
          <small>Seedance 图生视频 · 一键生成 Apple Live Photo</small>
        </span>
      </router-link>
      <nav class="nav">
        <router-link to="/">首页</router-link>
        <router-link to="/tasks">任务</router-link>
        <router-link to="/results">结果</router-link>
        <router-link to="/settings">设置</router-link>
      </nav>
      <div class="status-pill">
        <span class="dot"></span>
        Seedance Provider
      </div>
    </header>
    <main>
      <router-view />
    </main>
  </div>
</template>
