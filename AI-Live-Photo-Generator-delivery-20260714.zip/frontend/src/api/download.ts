export function absoluteDownload(url?: string) {
  if (!url) return '#'
  const appBase = import.meta.env.BASE_URL.replace(/\/$/, '')
  const apiBase = `${appBase || ''}/api`
  return url.startsWith('/api') ? `${appBase}${url}` : `${apiBase}${url}`
}
