import axios from 'axios'
import type { ApiResponse, Settings, TaskItem, TemplateItem, TemplateType } from '../types'

const appBase = import.meta.env.BASE_URL.replace(/\/$/, '')
const apiBase = `${appBase || ''}/api`

const client = axios.create({
  baseURL: apiBase,
  timeout: 30000
})

client.interceptors.response.use(
  response => response,
  error => {
    const message = error.response?.data?.message || error.message || '请求失败'
    return Promise.reject(new Error(message))
  }
)

export async function getTemplates() {
  const { data } = await client.get<ApiResponse<TemplateItem[]>>('/templates')
  return data.data
}

export async function createTask(image: File, template: TemplateType, durationSeconds: number) {
  const form = new FormData()
  form.append('image', image)
  form.append('template', template)
  form.append('durationSeconds', String(durationSeconds))
  const { data } = await client.post<ApiResponse<{ taskId: string }>>('/tasks', form)
  return data.data
}

export async function createBatchTasks(images: File[], template: TemplateType, durationSeconds: number) {
  const form = new FormData()
  images.forEach(image => form.append('images', image))
  form.append('template', template)
  form.append('durationSeconds', String(durationSeconds))
  const { data } = await client.post<ApiResponse<{ taskIds: string[] }>>('/tasks/batch', form, {
    timeout: 120000
  })
  return data.data
}

export async function retryTask(id: string) {
  const { data } = await client.post<ApiResponse<{ taskId: string }>>(`/tasks/${id}/retry`)
  return data.data
}

export async function downloadBatch(ids: string[]) {
  const response = await client.post('/tasks/download/batch', { ids }, {
    responseType: 'blob',
    timeout: 120000
  })
  const url = URL.createObjectURL(response.data)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = 'live-photo-batch.zip'
  anchor.click()
  URL.revokeObjectURL(url)
}

export async function getTask(id: string) {
  const { data } = await client.get<ApiResponse<TaskItem>>(`/tasks/${id}`)
  return data.data
}

export async function listTasks() {
  const { data } = await client.get<ApiResponse<TaskItem[]>>('/tasks')
  return data.data
}

export async function deleteTasks(ids: string[]) {
  const { data } = await client.delete<ApiResponse<number>>('/tasks', { data: { ids } })
  return data.data
}

export async function getSettings() {
  const { data } = await client.get<ApiResponse<Settings>>('/settings')
  return data.data
}

export async function updateSettings(payload: Partial<Settings> & { apiKey?: string }) {
  const { data } = await client.put<ApiResponse<Settings>>('/settings', payload)
  return data.data
}
