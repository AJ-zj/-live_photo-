import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import TaskView from '../views/TaskView.vue'
import ResultView from '../views/ResultView.vue'
import SettingsView from '../views/SettingsView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', name: 'home', component: HomeView },
    { path: '/tasks/:id?', name: 'tasks', component: TaskView },
    { path: '/results/:id?', name: 'results', component: ResultView },
    { path: '/settings', name: 'settings', component: SettingsView }
  ]
})

export default router
