import Foundation
import Photos
import UniformTypeIdentifiers

enum ImportStatus {
    case idle
    case working
    case success
    case failed
}

@MainActor
final class ImporterViewModel: ObservableObject {
    private static let defaultServerApiBase = "http://118.25.48.234/live/api"
    private static let serverApiBaseKey = "serverApiBase"

    @Published var status: ImportStatus = .idle
    @Published var message = "请选择网页下载的 Live Photo ZIP，或同时选择同名 JPG 和 MOV。"
    @Published var isWorking = false
    @Published var serverApiBase: String {
        didSet {
            UserDefaults.standard.set(serverApiBase, forKey: Self.serverApiBaseKey)
        }
    }
    @Published var taskId = ""

    private let zipExtractor = ZipExtractor()
    private let workflowClient = WorkflowClient()

    init() {
        serverApiBase = UserDefaults.standard.string(forKey: Self.serverApiBaseKey) ?? Self.defaultServerApiBase
    }

    func handlePickerResult(_ result: Result<[URL], Error>) async {
        do {
            let urls = try result.get()
            try await importFiles(urls)
        } catch {
            fail(error.localizedDescription)
        }
    }

    func importFromServer() async {
        do {
            try await importTask(apiBase: serverApiBase, taskId: taskId)
        } catch {
            fail(error.localizedDescription)
        }
    }

    private func importFiles(_ urls: [URL]) async throws {
        guard !urls.isEmpty else {
            return
        }
        status = .working
        message = "正在读取文件..."
        isWorking = true
        defer { isWorking = false }

        let workspace = try FileWorkspace()
        let localURLs = try urls.map { try workspace.copySecurityScopedFile($0) }
        try await importLocalURLs(localURLs, workspace: workspace)
    }

    private func importTask(apiBase: String, taskId: String) async throws {
        let cleanTaskIds = parseTaskIds(taskId)
        guard !cleanTaskIds.isEmpty else {
            throw ImporterError.missingTaskId
        }
        status = .working
        message = "正在连接服务器..."
        isWorking = true
        defer { isWorking = false }

        let apiBaseURL = try workflowClient.normalizedApiBase(apiBase)
        let workspace = try FileWorkspace()
        var downloadedZips: [URL] = []

        for (index, cleanTaskId) in cleanTaskIds.enumerated() {
            message = "正在查询任务 \(index + 1)/\(cleanTaskIds.count)..."
            let task = try await workflowClient.fetchTask(apiBase: apiBaseURL, taskId: cleanTaskId)
            guard task.task.status == "SUCCESS" else {
                throw ImporterError.taskNotReady(task.task.message ?? task.task.status)
            }
            guard let zipURL = workflowClient.downloadURL(from: task, apiBase: apiBaseURL) else {
                throw ImporterError.missingDownloadURL
            }
            message = "正在下载 Live Photo ZIP \(index + 1)/\(cleanTaskIds.count)..."
            let zipData = try await workflowClient.download(url: zipURL)
            let zipFile = try workspace.saveData(zipData, filename: "live-photo-\(cleanTaskId).zip")
            downloadedZips.append(zipFile)
        }

        try await importLocalURLs(downloadedZips, workspace: workspace)
    }

    private func importLocalURLs(_ urls: [URL], workspace: FileWorkspace) async throws {
        let zipURLs = urls.filter { $0.pathExtension.lowercased() == "zip" }
        let directURLs = urls.filter { $0.pathExtension.lowercased() != "zip" }
        var pairGroups: [[URL]] = []

        for (index, zip) in zipURLs.enumerated() {
            message = "正在解压 ZIP \(index + 1)/\(zipURLs.count)..."
            let extracted = try zipExtractor.extract(zipFile: zip, to: workspace.directory)
            pairGroups.append(extracted)
        }

        if !directURLs.isEmpty {
            pairGroups.append(directURLs)
        }

        let pairs = try LivePhotoPair.findAll(in: pairGroups.flatMap { $0 })

        message = "正在请求相册权限..."
        try await requestPhotoPermission()
        message = "正在写入 iPhone 相册 1/\(pairs.count)..."
        try await saveLivePhotos(pairs)
        status = .success
        message = "已保存 \(pairs.count) 张到照片 App。打开相册后应显示为可播放的实况照片。"
    }

    private func requestPhotoPermission() async throws {
        let current = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        if current == .authorized || current == .limited {
            return
        }
        let result = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard result == .authorized || result == .limited else {
            throw ImporterError.photoPermissionDenied
        }
    }

    private func saveLivePhotos(_ pairs: [LivePhotoPair]) async throws {
        try await PHPhotoLibrary.shared().performChanges {
            for pair in pairs {
                let request = PHAssetCreationRequest.forAsset()
                request.addResource(with: .photo, fileURL: pair.photoURL, options: nil)
                request.addResource(with: .pairedVideo, fileURL: pair.videoURL, options: nil)
            }
        }
    }

    private func parseTaskIds(_ text: String) -> [String] {
        text.components(separatedBy: CharacterSet(charactersIn: ",，\n\t "))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private func fail(_ text: String) {
        status = .failed
        message = text
        isWorking = false
    }
}

struct LivePhotoPair {
    let photoURL: URL
    let videoURL: URL

    static func find(in urls: [URL]) throws -> LivePhotoPair {
        guard let pair = try findAll(in: urls).first else {
            throw ImporterError.missingPair
        }
        return pair
    }

    static func findAll(in urls: [URL]) throws -> [LivePhotoPair] {
        let photos = urls.filter { ["jpg", "jpeg", "png"].contains($0.pathExtension.lowercased()) }
        let videos = urls.filter { ["mov", "qt"].contains($0.pathExtension.lowercased()) }
        var pairs: [LivePhotoPair] = []
        var usedVideoPaths = Set<String>()

        for photo in photos {
            let photoStem = photo.deletingPathExtension().lastPathComponent
            if let video = videos.first(where: {
                $0.deletingPathExtension().lastPathComponent == photoStem
                    && !usedVideoPaths.contains($0.path)
            }) {
                pairs.append(LivePhotoPair(photoURL: photo, videoURL: video))
                usedVideoPaths.insert(video.path)
            }
        }

        if pairs.isEmpty, photos.count == 1, videos.count == 1, let photo = photos.first, let video = videos.first {
            pairs.append(LivePhotoPair(photoURL: photo, videoURL: video))
        }

        guard !pairs.isEmpty else {
            throw ImporterError.missingPair
        }
        return pairs
    }
}

final class FileWorkspace {
    let directory: URL

    init() throws {
        directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("live-photo-import-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    func copySecurityScopedFile(_ source: URL) throws -> URL {
        let scoped = source.startAccessingSecurityScopedResource()
        defer {
            if scoped {
                source.stopAccessingSecurityScopedResource()
            }
        }
        let destination = uniqueURL(for: source.lastPathComponent)
        try FileManager.default.copyItem(at: source, to: destination)
        return destination
    }

    private func uniqueURL(for filename: String) -> URL {
        var candidate = directory.appendingPathComponent(filename)
        var index = 1
        while FileManager.default.fileExists(atPath: candidate.path) {
            let base = candidate.deletingPathExtension().lastPathComponent
            let ext = candidate.pathExtension
            candidate = directory.appendingPathComponent("\(base)-\(index)").appendingPathExtension(ext)
            index += 1
        }
        return candidate
    }

    func saveData(_ data: Data, filename: String) throws -> URL {
        let destination = uniqueURL(for: filename)
        try data.write(to: destination, options: .atomic)
        return destination
    }
}

enum ImporterError: LocalizedError {
    case missingPair
    case photoPermissionDenied
    case invalidZip
    case unsupportedZipEntry(String)
    case invalidServerURL
    case missingTaskId
    case taskNotReady(String)
    case missingDownloadURL
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .missingPair:
            return "没有找到可配对的 JPG 和 MOV。请确认 ZIP 内含同名 .jpg 和 .mov，或批量选择的文件里每张照片都有同名 MOV。"
        case .photoPermissionDenied:
            return "没有照片写入权限。请到系统设置中允许本 App 访问照片。"
        case .invalidZip:
            return "ZIP 文件格式不正确或无法读取。"
        case .unsupportedZipEntry(let name):
            return "ZIP 内文件暂不支持解压：\(name)。请先在“文件”App 中解压后选择 JPG 和 MOV。"
        case .invalidServerURL:
            return "服务器地址不正确。请填写类似 http://118.25.48.234/live/api 的 API 地址。"
        case .missingTaskId:
            return "请填写要导入的任务 ID。"
        case .taskNotReady(let message):
            return "任务还没有生成完成：\(message)"
        case .missingDownloadURL:
            return "任务结果里没有 Live Photo ZIP 下载地址。"
        case .serverError(let message):
            return message
        }
    }
}

struct WorkflowClient {
    func normalizedApiBase(_ text: String) throws -> URL {
        var value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        while value.hasSuffix("/") {
            value.removeLast()
        }
        if !value.hasSuffix("/api") {
            value += "/api"
        }
        guard let url = URL(string: value), url.scheme != nil, url.host != nil else {
            throw ImporterError.invalidServerURL
        }
        return url
    }

    func fetchTask(apiBase: URL, taskId: String) async throws -> WorkflowTaskPayload {
        let url = apiBase.appendingPathComponent("workflow/tasks").appendingPathComponent(taskId)
        let (data, response) = try await URLSession.shared.data(from: url)
        try validate(response: response)
        let wrapper = try JSONDecoder.livePhoto.decode(ApiWrapper<WorkflowTaskPayload>.self, from: data)
        guard wrapper.success, let payload = wrapper.data else {
            throw ImporterError.serverError(wrapper.message)
        }
        return payload
    }

    func download(url: URL) async throws -> Data {
        let (data, response) = try await URLSession.shared.data(from: url)
        try validate(response: response)
        return data
    }

    func downloadURL(from payload: WorkflowTaskPayload, apiBase: URL) -> URL? {
        let candidate = payload.downloads.livePhotoZip ?? payload.task.livePhotoUrl
        guard let value = candidate, !value.isEmpty else {
            return nil
        }
        if let absolute = URL(string: value), absolute.scheme != nil {
            return absolute
        }
        guard var components = URLComponents(url: apiBase, resolvingAgainstBaseURL: false) else {
            return nil
        }
        if value.hasPrefix("/api/") {
            let suffix = String(value.dropFirst("/api".count))
            components.path = apiBase.path + suffix
        } else if value.hasPrefix("/") {
            components.path = apiBase.path + value
        } else {
            components.path = apiBase.path + "/" + value
        }
        return components.url
    }

    private func validate(response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else {
            return
        }
        guard (200..<300).contains(http.statusCode) else {
            throw ImporterError.serverError("服务器返回错误状态：\(http.statusCode)")
        }
    }
}

struct ApiWrapper<T: Decodable>: Decodable {
    let success: Bool
    let message: String
    let data: T?
}

struct WorkflowTaskPayload: Decodable {
    let taskId: String
    let task: WorkflowTask
    let downloads: WorkflowDownloads
}

struct WorkflowTask: Decodable {
    let id: String
    let status: String
    let message: String?
    let livePhotoUrl: String?
}

struct WorkflowDownloads: Decodable {
    let jpg: String?
    let mov: String?
    let livePhotoZip: String?
}

private extension JSONDecoder {
    static var livePhoto: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
