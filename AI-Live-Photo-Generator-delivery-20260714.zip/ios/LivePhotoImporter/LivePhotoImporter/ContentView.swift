import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var viewModel = ImporterViewModel()
    @State private var showingPicker = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    header
                    serverImportPanel

                    Button {
                        showingPicker = true
                    } label: {
                        Label("批量选择 ZIP / JPG + MOV", systemImage: "square.and.arrow.down")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(viewModel.isWorking)

                    VStack(alignment: .leading, spacing: 10) {
                        Label("支持从服务器任务批量下载 ZIP", systemImage: "network")
                        Label("支持从“文件”App 多选 ZIP 或 JPG + MOV", systemImage: "archivebox")
                        Label("保存时会使用 Apple Photos API 创建实况照片", systemImage: "photo.badge.checkmark")
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))

                    StatusPanel(viewModel: viewModel)
                }
                .padding()
            }
            .navigationTitle("导入")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(
                isPresented: $showingPicker,
                allowedContentTypes: [.zip, .jpeg, .png, .quickTimeMovie, .movie],
                allowsMultipleSelection: true
            ) { result in
                Task {
                    await viewModel.handlePickerResult(result)
                }
            }
        }
    }

    private var header: some View {
        VStack(spacing: 10) {
            Image(systemName: "livephoto")
                .font(.system(size: 58, weight: .regular))
                .foregroundStyle(.blue)
            Text("AI实况照片")
                .font(.largeTitle.bold())
            Text("下载或选择生成好的 ZIP / JPG + MOV，保存为 iPhone 原生实况照片。")
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.top, 24)
    }

    private var serverImportPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("服务器任务导入", systemImage: "icloud.and.arrow.down")
                .font(.headline)

            TextField("服务器 API 地址", text: $viewModel.serverApiBase)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .textFieldStyle(.roundedBorder)

            TextField("任务 ID，可粘贴多个（换行 / 逗号）", text: $viewModel.taskId, axis: .vertical)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .lineLimit(1...4)
                .textFieldStyle(.roundedBorder)

            Button {
                Task {
                    await viewModel.importFromServer()
                }
            } label: {
                Label("下载并导入", systemImage: "square.and.arrow.down.on.square")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isWorking || viewModel.taskId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 12))
        .overlay {
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.separator), lineWidth: 0.5)
        }
    }
}

private struct StatusPanel: View {
    @ObservedObject var viewModel: ImporterViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: viewModel.status.icon)
                    .foregroundStyle(viewModel.status.color)
                Text(viewModel.status.title)
                    .font(.headline)
            }
            Text(viewModel.message)
                .font(.body)
                .foregroundStyle(.secondary)
                .textSelection(.enabled)
            if viewModel.isWorking {
                ProgressView()
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 12))
        .overlay {
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.separator), lineWidth: 0.5)
        }
    }
}

private extension ImportStatus {
    var title: String {
        switch self {
        case .idle:
            return "等待选择文件"
        case .working:
            return "正在导入"
        case .success:
            return "导入成功"
        case .failed:
            return "导入失败"
        }
    }

    var icon: String {
        switch self {
        case .idle:
            return "tray"
        case .working:
            return "arrow.triangle.2.circlepath"
        case .success:
            return "checkmark.circle.fill"
        case .failed:
            return "xmark.octagon.fill"
        }
    }

    var color: Color {
        switch self {
        case .idle:
            return .secondary
        case .working:
            return .blue
        case .success:
            return .green
        case .failed:
            return .red
        }
    }
}
