import Compression
import Foundation

final class ZipExtractor {
    func extract(zipFile: URL, to directory: URL) throws -> [URL] {
        let data = try Data(contentsOf: zipFile)
        let entries = try centralDirectoryEntries(in: data)
        var output: [URL] = []

        for entry in entries where isWanted(entry.name) {
            let payload = try filePayload(for: entry, in: data)
            let fileData: Data
            switch entry.compressionMethod {
            case 0:
                fileData = payload
            case 8:
                fileData = try inflate(payload, expectedSize: Int(entry.uncompressedSize), name: entry.name)
            default:
                throw ImporterError.unsupportedZipEntry(entry.name)
            }
            let destination = uniqueURL(
                in: directory,
                filename: URL(fileURLWithPath: entry.name).lastPathComponent
            )
            try fileData.write(to: destination, options: .atomic)
            output.append(destination)
        }

        return output
    }

    private func uniqueURL(in directory: URL, filename: String) -> URL {
        let original = directory.appendingPathComponent(filename)
        let stem = original.deletingPathExtension().lastPathComponent
        let ext = original.pathExtension
        var candidate = original
        var index = 1

        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("\(stem)-\(index)").appendingPathExtension(ext)
            index += 1
        }

        return candidate
    }

    private func isWanted(_ name: String) -> Bool {
        let ext = URL(fileURLWithPath: name).pathExtension.lowercased()
        return ["jpg", "jpeg", "png", "mov", "qt"].contains(ext)
    }

    private func centralDirectoryEntries(in data: Data) throws -> [ZipEntry] {
        guard let eocd = findEndOfCentralDirectory(in: data) else {
            throw ImporterError.invalidZip
        }
        let count = Int(data.uint16(at: eocd + 10))
        var offset = Int(data.uint32(at: eocd + 16))
        var entries: [ZipEntry] = []

        for _ in 0..<count {
            guard data.uint32(at: offset) == 0x02014b50 else {
                throw ImporterError.invalidZip
            }
            let method = data.uint16(at: offset + 10)
            let compressedSize = data.uint32(at: offset + 20)
            let uncompressedSize = data.uint32(at: offset + 24)
            let nameLength = Int(data.uint16(at: offset + 28))
            let extraLength = Int(data.uint16(at: offset + 30))
            let commentLength = Int(data.uint16(at: offset + 32))
            let localHeaderOffset = data.uint32(at: offset + 42)
            let nameStart = offset + 46
            let nameData = data.subdata(in: nameStart..<(nameStart + nameLength))
            let name = String(data: nameData, encoding: .utf8) ?? String(data: nameData, encoding: .isoLatin1) ?? ""
            entries.append(ZipEntry(
                name: name,
                compressionMethod: method,
                compressedSize: compressedSize,
                uncompressedSize: uncompressedSize,
                localHeaderOffset: localHeaderOffset
            ))
            offset = nameStart + nameLength + extraLength + commentLength
        }
        return entries
    }

    private func findEndOfCentralDirectory(in data: Data) -> Int? {
        let signature: UInt32 = 0x06054b50
        let lowerBound = max(0, data.count - 66_000)
        guard data.count >= 22 else {
            return nil
        }
        for offset in stride(from: data.count - 22, through: lowerBound, by: -1) {
            if data.uint32(at: offset) == signature {
                return offset
            }
        }
        return nil
    }

    private func filePayload(for entry: ZipEntry, in data: Data) throws -> Data {
        let offset = Int(entry.localHeaderOffset)
        guard data.uint32(at: offset) == 0x04034b50 else {
            throw ImporterError.invalidZip
        }
        let nameLength = Int(data.uint16(at: offset + 26))
        let extraLength = Int(data.uint16(at: offset + 28))
        let payloadStart = offset + 30 + nameLength + extraLength
        let payloadEnd = payloadStart + Int(entry.compressedSize)
        guard payloadEnd <= data.count else {
            throw ImporterError.invalidZip
        }
        return data.subdata(in: payloadStart..<payloadEnd)
    }

    private func inflate(_ data: Data, expectedSize: Int, name: String) throws -> Data {
        var output = Data(count: expectedSize)
        let decodedCount = output.withUnsafeMutableBytes { outputBuffer in
            data.withUnsafeBytes { inputBuffer in
                compression_decode_buffer(
                    outputBuffer.bindMemory(to: UInt8.self).baseAddress!,
                    expectedSize,
                    inputBuffer.bindMemory(to: UInt8.self).baseAddress!,
                    data.count,
                    nil,
                    COMPRESSION_ZLIB
                )
            }
        }
        guard decodedCount > 0 else {
            throw ImporterError.unsupportedZipEntry(name)
        }
        output.removeSubrange(decodedCount..<output.count)
        return output
    }
}

private struct ZipEntry {
    let name: String
    let compressionMethod: UInt16
    let compressedSize: UInt32
    let uncompressedSize: UInt32
    let localHeaderOffset: UInt32
}

private extension Data {
    func uint16(at offset: Int) -> UInt16 {
        UInt16(self[offset]) | (UInt16(self[offset + 1]) << 8)
    }

    func uint32(at offset: Int) -> UInt32 {
        UInt32(self[offset])
            | (UInt32(self[offset + 1]) << 8)
            | (UInt32(self[offset + 2]) << 16)
            | (UInt32(self[offset + 3]) << 24)
    }
}
